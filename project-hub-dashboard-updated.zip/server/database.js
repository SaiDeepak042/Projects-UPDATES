// --- IN-MEMORY DATABASE (SERVER-SIDE) ---

import { ActivityActionType } from '../shared/ActivityActionType.js';

let users = [
  { id: 'u1', name: 'A. Mahendra Reddy', designation: 'Junior Software Developer', department: 'IT', email: 'mahendra@fdesindia.com', projects: ['Titan BCM'], avatar: 'https://i.pravatar.cc/40?u=u1' },
  { id: 'u2', name: 'Abhijith P T', designation: 'Design Automation Specialist', department: 'CAD', email: 'abhijith@fdesindia.com', projects: ['Creo'], avatar: 'https://i.pravatar.cc/40?u=u2' },
  { id: 'u3', name: 'Ane Lakshmi Sai Deepak', designation: 'Design Automation Specialist', department: 'IT', email: 'deepak@fdesindia.com', projects: ['Gaylord', 'Titan BCM'], avatar: 'https://i.pravatar.cc/40?u=u3' },
  { id: 'u4', name: 'Anumala Gopi Prasanna', designation: 'Junior Software Developer', department: 'IT', email: 'gopiprasanna@fdesindia.com', projects: ['Wizz Time'], avatar: 'https://i.pravatar.cc/40?u=u4' },
  { id: 'u5', name: 'Anusha Kokkula', designation: 'Trainee Design Automation Engineer', department: 'CAD', email: 'anusha@fdesindia.com', projects: ['Strata'], avatar: 'https://i.pravatar.cc/40?u=u5' },
  { id: 'u6', name: 'Arshitha Pineddy', designation: 'Trainee Design Automation Engineer', department: 'CAD', email: 'arshitha@fdesindia.com', projects: ['Unicranes'], avatar: 'https://i.pravatar.cc/40?u=u6' },
  { id: 'u7', name: 'Atharva Arvind Shende', designation: 'Junior AI Programmer', department: 'IT', email: 'atharva@fdesindia.com', projects: ['Creo'], avatar: 'https://i.pravatar.cc/40?u=u7' },
  { id: 'u8', name: 'Balagani Sai Dhanya', designation: 'Junior Software Developer', department: 'IT', email: 'saidhanya@fdesindia.com', projects: ['Titan BCM', 'CETS', 'Wizz Time'], avatar: 'https://i.pravatar.cc/40?u=u8' },
  { id: 'u9', name: 'Bhageshwar Srimangali', designation: 'Trainee Design Automation Engineer', department: 'CAD', email: 'bhageshwar@fdesindia.com', projects: ['Titan BCM', 'Mukand'], avatar: 'https://i.pravatar.cc/40?u=u9' },
  { id: 'u10', name: 'Chandu Swargam', designation: 'Trainee Design Automation Engineer', department: 'CAD', email: 'chandu@fdesindia.com', projects: ['Unicranes'], avatar: 'https://i.pravatar.cc/40?u=u10' },
  { id: 'u11', name: 'Galipelli Swarna Kumari', designation: 'Software Developer', department: 'IT', email: 'swarnakumari@fdesindia.com', projects: ['Wizz Time'], avatar: 'https://i.pravatar.cc/40?u=u11' },
  { id: 'u12', name: 'Kanike Thirumalesh', designation: 'Software Developer', department: 'IT', email: 'thirumalesh@fdesindia.com', projects: ['Titan BCM', 'CETS', 'SVG Next'], avatar: 'https://i.pravatar.cc/40?u=u12' },
  { id: 'u13', name: 'Kankipati Ratna Kiran', designation: 'Software Developer', department: 'IT', email: 'ratnakiran@fdesindia.com', projects: ['SVG Next'], avatar: 'https://i.pravatar.cc/40?u=u13' },
  { id: 'u14', name: 'Kodati Bhanu Prakash', designation: 'Junior Software Developer', department: 'IT', email: 'bhanuprakash@fdesindia.com', projects: ['Unicranes'], avatar: 'https://i.pravatar.cc/40?u=u14' },
  { id: 'u15', name: 'Kora Nagarjuna Reddy', designation: 'Director', department: 'Management', email: 'nag@fdestech.com', projects: [], avatar: 'https://i.pravatar.cc/40?u=u15' },
  { id: 'u16', name: 'Kummari Ravi Kumar', designation: 'Design Automation Specialist', department: 'IT', email: 'ravikumar@fdesindia.com', projects: ['Satrac', 'Strata'], avatar: 'https://i.pravatar.cc/40?u=u16' },
  { id: 'u17', name: 'Manepalli Surya Chandra Rao', designation: 'Trainee Design Automation Engineer', department: 'CAD', email: 'suryachandrarao@fdesindia.com', projects: ['Mukand'], avatar: 'https://i.pravatar.cc/40?u=u17' },
  { id: 'u18', name: 'Manideep Boga', designation: 'Trainee Design Automation Engineer', department: 'CAD', email: 'manideep@fdesindia.com', projects: ['Satrac'], avatar: 'https://i.pravatar.cc/40?u=u18' },
  { id: 'u19', name: 'Medapati Navalika', designation: 'Product Configurator Specialist', department: 'IT', email: 'navalika@fdesindia.com', projects: ['Sofa Configurator'], avatar: 'https://i.pravatar.cc/40?u=u19' },
  { id: 'u20', name: 'Meruva Venkata Sai', designation: 'Junior Design Automation Engineer', department: 'CAD', email: 'venkatasai@fdesindia.com', projects: ['Mukand'], avatar: 'https://i.pravatar.cc/40?u=u20' },
  { id: 'u21', name: 'Munipalli Akshith', designation: 'Design Automation Specialist', department: 'IT', email: 'akshith@fdesindia.com', projects: ['Grid Structures'], avatar: 'https://i.pravatar.cc/40?u=u21' },
  { id: 'u22', name: 'Nallapaneni Suneel Kumar', designation: 'Junior Design Automation Engineer', department: 'CAD', email: 'suneelkumar@fdesindia.com', projects: ['Grid Structures'], avatar: 'https://i.pravatar.cc/40?u=u22' },
  { id: 'u23', name: 'Neha Boorla', designation: 'Trainee Design Automation Engineer', department: 'CAD', email: 'nehabhavani@fdesindia.com', projects: ['Titan BCM', 'Mukand'], avatar: 'https://i.pravatar.cc/40?u=u23' },
  { id: 'u24', name: 'Rachamallu Prasanna', designation: 'Director', department: 'Management', email: 'hr@fdestech.com', projects: [], avatar: 'https://i.pravatar.cc/40?u=u24' },
  { id: 'u25', name: 'Sanjay Kumar Jella', designation: 'Trainee Design Automation Engineer', department: 'CAD', email: 'sanjaykumar@fdesindia.com', projects: ['Satrac'], avatar: 'https://i.pravatar.cc/40?u=u25' },
  { id: 'u26', name: 'Shaikh Abubakar', designation: 'Junior AI Programmer', department: 'IT', email: 'abubakar@fdesindia.com', projects: ['Creo'], avatar: 'https://i.pravatar.cc/40?u=u26' },
  { id: 'u27', name: 'Shivlad Rajesh Nagnath', designation: 'Software Developer', department: 'IT', email: 'rajesh.sr@fdesindia.com', projects: ['Grid Structures', 'CETS', 'Wizz Time'], avatar: 'https://i.pravatar.cc/40?u=u27' },
  { id: 'u28', name: 'Vasanthi Naidu', designation: 'HR Generalist', department: 'HR', email: 'vasanthi@fdestech.com', projects: [], avatar: 'https://i.pravatar.cc/40?u=u28' },
  { id: 'u29', name: 'Yannam Karthikeya', designation: 'Junior Design Automation Engineer', department: 'CAD', email: 'karthikeya@fdesindia.com', projects: ['Mukand'], avatar: 'https://i.pravatar.cc/40?u=u29' }
];

let projects = [
  {
    id: 'p1',
    name: 'Project Phoenix',
    description: 'Launch a new marketing campaign for the holiday season to boost sales by 20%. The campaign will include social media, email marketing, and influencer collaborations.',
    leaderId: 'u2',
    teamMemberIds: ['u2', 'u3', 'u4', 'u7'],
    dueDate: '2024-12-20T00:00:00.000Z',
    status: 'In Progress',
    progress: 33,
    tasks: [
      { id: 't1', title: 'Design social media assets', description: 'Create visuals for Instagram, Facebook, and Twitter.', status: 'Done', priority: 'High', dueDate: '2024-11-15T00:00:00.000Z', assigneeId: 'u3', creatorId: 'u2', createdOn: '2024-11-01T00:00:00.000Z', updatedOn: '2024-11-10T00:00:00.000Z', type: 'Task', category: 'Design', projectId: 'p1', projectName: 'Project Phoenix' },
      { id: 't2', title: 'Finalize influencer list', description: 'Identify and confirm 5 key influencers for the campaign.', status: 'In Progress', priority: 'Medium', dueDate: '2024-11-20T00:00:00.000Z', assigneeId: 'u4', creatorId: 'u2', createdOn: '2024-11-05T00:00:00.000Z', updatedOn: '2024-11-12T00:00:00.000Z', type: 'Task', category: 'Marketing', projectId: 'p1', projectName: 'Project Phoenix' },
      { id: 't3', title: 'Draft email copy', description: 'Write compelling copy for 3 promotional emails.', status: 'Review', priority: 'Normal', dueDate: '2024-11-22T00:00:00.000Z', assigneeId: 'u3', creatorId: 'u2', createdOn: '2024-11-10T00:00:00.000Z', updatedOn: '2024-11-18T00:00:00.000Z', type: 'Task', category: 'Content', projectId: 'p1', projectName: 'Project Phoenix' },
    ],
    activities: [
        { id: 'a1', userId: 'u2', actionType: ActivityActionType.PROJECT_CREATED, timestamp: '2024-11-01T09:00:00.000Z', details: { projectName: 'Project Phoenix' } },
        { id: 'a2', userId: 'u2', actionType: ActivityActionType.TASK_CREATED, timestamp: '2024-11-01T09:05:00.000Z', details: { taskTitle: 'Design social media assets' } },
    ],
    clientInputs: [],
    meetings: [],
    estimations: [
        { id: 'est1', projectId: 'p1', phase: 'Phase 1 - Core Features', projectType: 'Web', featureTask: 'Authentication', subtask: 'Login Page UI', complexity: 'Low', estimatedHours: 8, dependencies: '', developerNotes: '', riskLevel: 'Low', technologyStack: 'React, TypeScript', priority: 'High', createdOn: '2024-07-01T10:00:00.000Z', updatedOn: '2024-07-01T10:00:00.000Z', creatorId: 'u2' },
        { id: 'est2', projectId: 'p1', phase: 'Phase 1 - Core Features', projectType: 'Web', featureTask: 'Authentication', subtask: 'Backend API for Login', complexity: 'Medium', estimatedHours: 16, dependencies: 'Database schema', developerNotes: '', riskLevel: 'Low', technologyStack: 'Node.js, Express', priority: 'High', createdOn: '2024-07-01T11:00:00.000Z', updatedOn: '2024-07-01T11:00:00.000Z', creatorId: 'u2' },
    ],
    scopeOfWork: [
        { id: 'sow1', projectId: 'p1', scopeOfWork: 'CAD + Web', featureModule: 'Data Sync Module', taskSubtask: 'CAD Plugin Export', description: 'Implement function to export CAD model data', deliverables: 'CAD data export file (JSON/CSV)', acceptanceCriteria: 'Data matches original CAD model', estimatedEffort: 10, dependencies: 'CAD SDK', responsibleParty: 'u2', priority: 'High', riskLevel: 'Medium', notes: 'Optimize for large models' },
        { id: 'sow2', projectId: 'p1', scopeOfWork: 'CAD + Web', featureModule: 'Data Sync Module', taskSubtask: 'Web Import', description: 'Build backend API to import CAD data', deliverables: 'API endpoint with success response', acceptanceCriteria: 'Data imported successfully', estimatedEffort: 8, dependencies: 'DB Setup', responsibleParty: 'u3', priority: 'High', riskLevel: 'Medium', notes: 'Include error handling' },
        { id: 'sow3', projectId: 'p1', scopeOfWork: 'Web', featureModule: 'User Authentication', taskSubtask: 'Frontend Login UI', description: 'Build responsive login form', deliverables: 'Login page with validation', acceptanceCriteria: 'User can login successfully', estimatedEffort: 6, dependencies: 'Backend API', responsibleParty: 'u2', priority: 'High', riskLevel: 'Medium', notes: 'Use company UI standards' },
    ]
  },
  {
    id: 'p2',
    name: 'Mobile App Redesign',
    description: 'Complete overhaul of the user interface and user experience for our flagship mobile application. Focus on improving navigation and performance.',
    leaderId: 'u1',
    teamMemberIds: ['u1', 'u5', 'u7'],
    dueDate: '2025-02-15T00:00:00.000Z',
    status: 'On Hold',
    progress: 0,
    tasks: [], activities: [], clientInputs: [], meetings: [], estimations: [], scopeOfWork: [],
  },
  {
    id: 'p3',
    name: 'Website Performance Optimization',
    description: 'Improve website loading speed and overall performance. Target a Lighthouse score of 90+ on all key pages.',
    leaderId: 'u2',
    teamMemberIds: ['u2', 'u5'],
    dueDate: '2024-11-30T00:00:00.000Z',
    status: 'Completed',
    progress: 100,
    tasks: [], activities: [], clientInputs: [], meetings: [], estimations: [], scopeOfWork: [],
  }
];

// --- ID Generation ---
let nextUserId = users.length + 1;
let nextProjectId = projects.length + 1;
let nextTaskId = projects.flatMap(p => p.tasks).length + 1;
let nextActivityId = projects.flatMap(p => p.activities).length + 1;
let nextInputId = projects.flatMap(p => p.clientInputs || []).length + 1;
let nextMeetingId = projects.flatMap(p => p.meetings || []).length + 1;
let nextEstimationId = projects.flatMap(p => p.estimations || []).length + 1;
let nextScopeOfWorkId = projects.flatMap(p => p.scopeOfWork || []).length + 1;


// --- HELPERS ---
const calculateProgress = (project) => {
    if (!project || !project.tasks || project.tasks.length === 0) return 0;
    const completedTasks = project.tasks.filter(t => t.status === 'Done').length;
    return Math.round((completedTasks / project.tasks.length) * 100);
}

const logActivity = (project, userId, actionType, details) => {
    if (!project) return;
    const newActivity = {
        id: `a${nextActivityId++}`,
        userId,
        actionType,
        timestamp: new Date().toISOString(),
        details,
    };
    if (!project.activities) project.activities = [];
    project.activities.push(newActivity);
    project.activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
};

const getProjectById = (id) => projects.find(p => p.id === id);


// --- DATABASE FUNCTIONS ---

const db = {
    // Users
    getUsers: () => JSON.parse(JSON.stringify(users)),
    createUser: (userData) => {
        const newUser = {
            id: `u${nextUserId++}`,
            name: userData.name || '',
            designation: userData.designation || 'Trainee',
            department: userData.department || 'IT',
            email: userData.email || '',
            projects: Array.isArray(userData.projects) 
                ? userData.projects 
                : (userData.projects || '').split(',').map(p => p.trim()).filter(Boolean),
            avatar: userData.avatar || `https://i.pravatar.cc/40?u=${userData.email}`
        };
        users.push(newUser);
        return JSON.parse(JSON.stringify(newUser));
    },

    // Projects
    getProjects: () => JSON.parse(JSON.stringify(projects)),

    createProject: (projectData, userId) => {
        const newProject = {
            ...projectData,
            id: `p${nextProjectId++}`,
            status: 'In Progress',
            progress: 0,
            tasks: [],
            activities: [],
            clientInputs: [],
            meetings: [],
            estimations: [],
            scopeOfWork: [],
        };
        logActivity(newProject, userId, ActivityActionType.PROJECT_CREATED, { projectName: newProject.name });
        projects.push(newProject);
        return JSON.parse(JSON.stringify(newProject));
    },

    updateProject: (id, updatedProjectData, userId) => {
        const projectIndex = projects.findIndex(p => p.id === id);
        if (projectIndex === -1) return null;
        
        projects[projectIndex] = { ...projects[projectIndex], ...updatedProjectData };
        logActivity(projects[projectIndex], userId, ActivityActionType.PROJECT_UPDATED, { projectName: projects[projectIndex].name });
        return JSON.parse(JSON.stringify(projects[projectIndex]));
    },

    deleteProject: (id) => {
        const initialLength = projects.length;
        projects = projects.filter(p => p.id !== id);
        return projects.length < initialLength;
    },

    // Tasks
    createTask: (projectId, taskData, userId) => {
        const project = getProjectById(projectId);
        if (!project) return null;

        const newTask = {
            ...taskData,
            id: `t${nextTaskId++}`,
            creatorId: userId,
            createdOn: new Date().toISOString(),
            updatedOn: new Date().toISOString(),
            projectId: project.id,
            projectName: project.name,
        };
        if (!project.tasks) project.tasks = [];
        project.tasks.push(newTask);
        project.progress = calculateProgress(project);
        logActivity(project, userId, ActivityActionType.TASK_CREATED, { taskTitle: newTask.title });
        return JSON.parse(JSON.stringify(newTask));
    },

    updateTask: (projectId, taskId, taskData, userId) => {
        const project = getProjectById(projectId);
        if (!project) return null;
        const taskIndex = project.tasks.findIndex(t => t.id === taskId);
        if (taskIndex === -1) return null;

        project.tasks[taskIndex] = { ...project.tasks[taskIndex], ...taskData, updatedOn: new Date().toISOString() };
        project.progress = calculateProgress(project);
        logActivity(project, userId, ActivityActionType.TASK_UPDATED, { taskTitle: project.tasks[taskIndex].title });
        return JSON.parse(JSON.stringify(project.tasks[taskIndex]));
    },

    deleteTask: (projectId, taskId, userId) => {
        const project = getProjectById(projectId);
        if (!project) return null;
        
        const taskToDelete = project.tasks.find(t => t.id === taskId);
        if (!taskToDelete) return null;
        
        project.tasks = project.tasks.filter(t => t.id !== taskId);
        project.progress = calculateProgress(project);
        logActivity(project, userId, ActivityActionType.TASK_DELETED, { taskTitle: taskToDelete.title });
        return JSON.parse(JSON.stringify(taskToDelete));
    },

    // Client Inputs
    createClientInput: (projectId, inputData, userId) => {
        const project = getProjectById(projectId);
        if (!project) return null;

        const newInput = { ...inputData, id: `ci${nextInputId++}` };
        if (!project.clientInputs) project.clientInputs = [];
        project.clientInputs.push(newInput);
        logActivity(project, userId, ActivityActionType.INPUT_CREATED, { inputDescription: newInput.description });
        return JSON.parse(JSON.stringify(newInput));
    },

    updateClientInput: (projectId, inputId, inputData, userId) => {
        const project = getProjectById(projectId);
        if (!project || !project.clientInputs) return null;
        
        const inputIndex = project.clientInputs.findIndex(i => i.id === inputId);
        if (inputIndex === -1) return null;

        project.clientInputs[inputIndex] = { ...project.clientInputs[inputIndex], ...inputData };
        logActivity(project, userId, ActivityActionType.INPUT_UPDATED, { inputDescription: project.clientInputs[inputIndex].description });
        return JSON.parse(JSON.stringify(project.clientInputs[inputIndex]));
    },

    deleteClientInput: (projectId, inputId, userId) => {
        const project = getProjectById(projectId);
        if (!project || !project.clientInputs) return null;
        
        const inputToDelete = project.clientInputs.find(i => i.id === inputId);
        if (!inputToDelete) return null;

        project.clientInputs = project.clientInputs.filter(i => i.id !== inputId);
        logActivity(project, userId, ActivityActionType.INPUT_DELETED, { inputDescription: inputToDelete.description });
        return JSON.parse(JSON.stringify(inputToDelete));
    },

    // Meetings
    createMeeting: (projectId, meetingData, userId) => {
        const project = getProjectById(projectId);
        if (!project) return null;

        const newMeeting = { ...meetingData, id: `m${nextMeetingId++}` };
        if (!project.meetings) project.meetings = [];
        project.meetings.push(newMeeting);
        logActivity(project, userId, ActivityActionType.MEETING_CREATED, { meetingTitle: newMeeting.title });
        return JSON.parse(JSON.stringify(newMeeting));
    },

    // Estimations
    createEstimation: (projectId, estimationData, userId) => {
        const project = getProjectById(projectId);
        if (!project) return null;

        const newEstimation = {
            ...estimationData,
            id: `est${nextEstimationId++}`,
            creatorId: userId,
            createdOn: new Date().toISOString(),
            updatedOn: new Date().toISOString(),
            projectId: project.id,
        };
        if (!project.estimations) project.estimations = [];
        project.estimations.push(newEstimation);
        logActivity(project, userId, ActivityActionType.ESTIMATION_CREATED, { 
            estimationTitle: `${newEstimation.featureTask} - ${newEstimation.subtask}`,
            estimationId: newEstimation.id 
        });
        return JSON.parse(JSON.stringify(newEstimation));
    },

    updateEstimation: (projectId, estimationId, estimationData, userId) => {
        const project = getProjectById(projectId);
        if (!project || !project.estimations) return null;
        const estimationIndex = project.estimations.findIndex(e => e.id === estimationId);
        if (estimationIndex === -1) return null;

        project.estimations[estimationIndex] = { ...project.estimations[estimationIndex], ...estimationData, updatedOn: new Date().toISOString() };
        logActivity(project, userId, ActivityActionType.ESTIMATION_UPDATED, { 
            estimationTitle: `${project.estimations[estimationIndex].featureTask} - ${project.estimations[estimationIndex].subtask}`,
            estimationId: estimationId
        });
        return JSON.parse(JSON.stringify(project.estimations[estimationIndex]));
    },

    deleteEstimation: (projectId, estimationId, userId) => {
        const project = getProjectById(projectId);
        if (!project || !project.estimations) return null;
        
        const estimationToDelete = project.estimations.find(e => e.id === estimationId);
        if (!estimationToDelete) return null;
        
        logActivity(project, userId, ActivityActionType.ESTIMATION_DELETED, { 
            estimationTitle: `${estimationToDelete.featureTask} - ${estimationToDelete.subtask}`,
            estimationId: estimationId
        });
        
        project.estimations = project.estimations.filter(e => e.id !== estimationId);
        return JSON.parse(JSON.stringify(estimationToDelete));
    },

    // Scope Of Work
    createScopeOfWork: (projectId, scopeData, userId) => {
        const project = getProjectById(projectId);
        if (!project) return null;

        const newScope = { ...scopeData, id: `sow${nextScopeOfWorkId++}`, projectId: project.id };
        if (!project.scopeOfWork) project.scopeOfWork = [];
        project.scopeOfWork.push(newScope);
        logActivity(project, userId, ActivityActionType.SCOPE_CREATED, { 
            scopeTitle: `${newScope.featureModule} - ${newScope.taskSubtask}`
        });
        return JSON.parse(JSON.stringify(newScope));
    },

    updateScopeOfWork: (projectId, scopeId, scopeData, userId) => {
        const project = getProjectById(projectId);
        if (!project || !project.scopeOfWork) return null;
        const scopeIndex = project.scopeOfWork.findIndex(s => s.id === scopeId);
        if (scopeIndex === -1) return null;

        project.scopeOfWork[scopeIndex] = { ...project.scopeOfWork[scopeIndex], ...scopeData };
        logActivity(project, userId, ActivityActionType.SCOPE_UPDATED, { 
            scopeTitle: `${project.scopeOfWork[scopeIndex].featureModule} - ${project.scopeOfWork[scopeIndex].taskSubtask}`
        });
        return JSON.parse(JSON.stringify(project.scopeOfWork[scopeIndex]));
    },

    deleteScopeOfWork: (projectId, scopeId, userId) => {
        const project = getProjectById(projectId);
        if (!project || !project.scopeOfWork) return null;
        
        const scopeToDelete = project.scopeOfWork.find(s => s.id === scopeId);
        if (!scopeToDelete) return null;
        
        logActivity(project, userId, ActivityActionType.SCOPE_DELETED, { 
            scopeTitle: `${scopeToDelete.featureModule} - ${scopeToDelete.taskSubtask}`
        });
        
        project.scopeOfWork = project.scopeOfWork.filter(s => s.id !== scopeId);
        return JSON.parse(JSON.stringify(scopeToDelete));
    },
};

export default db;