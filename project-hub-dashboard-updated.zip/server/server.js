

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import db from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware to parse JSON bodies
app.use(express.json());

// --- API ROUTES ---
const apiRouter = express.Router();

// User routes
apiRouter.get('/users', (req, res) => res.json(db.getUsers()));
apiRouter.post('/users', (req, res) => res.status(201).json(db.createUser(req.body)));

// Project routes
apiRouter.get('/projects', (req, res) => res.json(db.getProjects()));
apiRouter.post('/projects', (req, res) => {
    const { projectData, userId } = req.body;
    res.status(201).json(db.createProject(projectData, userId));
});
apiRouter.put('/projects/:id', (req, res) => {
    const { updatedProjectData, userId } = req.body;
    const project = db.updateProject(req.params.id, updatedProjectData, userId);
    if (project) {
        res.json(project);
    } else {
        res.status(404).send('Project not found');
    }
});
apiRouter.delete('/projects/:id', (req, res) => {
    if (db.deleteProject(req.params.id)) {
        res.status(204).send();
    } else {
        res.status(404).send('Project not found');
    }
});

// Task routes
apiRouter.post('/projects/:projectId/tasks', (req, res) => {
    const { taskData, userId } = req.body;
    const task = db.createTask(req.params.projectId, taskData, userId);
    if (task) {
        res.status(201).json(task);
    } else {
        res.status(404).send('Project not found');
    }
});
apiRouter.put('/projects/:projectId/tasks/:taskId', (req, res) => {
    const { taskData, userId } = req.body;
    const task = db.updateTask(req.params.projectId, req.params.taskId, taskData, userId);
    if (task) {
        res.json(task);
    } else {
        res.status(404).send('Task not found');
    }
});
apiRouter.delete('/projects/:projectId/tasks/:taskId', (req, res) => {
    const { userId } = req.body;
    const task = db.deleteTask(req.params.projectId, req.params.taskId, userId);
    if (task) {
        res.status(204).send();
    } else {
        res.status(404).send('Task not found');
    }
});

// Client Input routes
apiRouter.post('/projects/:projectId/client-inputs', (req, res) => {
    const { inputData, userId } = req.body;
    const input = db.createClientInput(req.params.projectId, inputData, userId);
    res.status(201).json(input);
});
apiRouter.put('/projects/:projectId/client-inputs/:inputId', (req, res) => {
    const { inputData, userId } = req.body;
    const input = db.updateClientInput(req.params.projectId, req.params.inputId, inputData, userId);
    res.json(input);
});
apiRouter.delete('/projects/:projectId/client-inputs/:inputId', (req, res) => {
    const { userId } = req.body;
    db.deleteClientInput(req.params.projectId, req.params.inputId, userId);
    res.status(204).send();
});

// Meeting routes
apiRouter.post('/projects/:projectId/meetings', (req, res) => {
    const { meetingData, userId } = req.body;
    const meeting = db.createMeeting(req.params.projectId, meetingData, userId);
    res.status(201).json(meeting);
});

// Estimation routes
apiRouter.post('/projects/:projectId/estimations', (req, res) => {
    const { estimationData, userId } = req.body;
    const estimation = db.createEstimation(req.params.projectId, estimationData, userId);
    if (estimation) {
        res.status(201).json(estimation);
    } else {
        res.status(404).send('Project not found');
    }
});
apiRouter.put('/projects/:projectId/estimations/:estimationId', (req, res) => {
    const { estimationData, userId } = req.body;
    const estimation = db.updateEstimation(req.params.projectId, req.params.estimationId, estimationData, userId);
    if (estimation) {
        res.json(estimation);
    } else {
        res.status(404).send('Estimation not found');
    }
});
apiRouter.delete('/projects/:projectId/estimations/:estimationId', (req, res) => {
    const { userId } = req.body; // Although unused in DB logic, good to have for permissions later
    const estimation = db.deleteEstimation(req.params.projectId, req.params.estimationId, userId);
    if (estimation) {
        res.status(204).send();
    } else {
        res.status(404).send('Estimation not found');
    }
});

// Scope of Work routes
apiRouter.post('/projects/:projectId/scope-of-work', (req, res) => {
    const { scopeData, userId } = req.body;
    const scopeItem = db.createScopeOfWork(req.params.projectId, scopeData, userId);
    if (scopeItem) {
        res.status(201).json(scopeItem);
    } else {
        res.status(404).send('Project not found');
    }
});
apiRouter.put('/projects/:projectId/scope-of-work/:scopeId', (req, res) => {
    const { scopeData, userId } = req.body;
    const scopeItem = db.updateScopeOfWork(req.params.projectId, req.params.scopeId, scopeData, userId);
    if (scopeItem) {
        res.json(scopeItem);
    } else {
        res.status(404).send('Scope item not found');
    }
});
apiRouter.delete('/projects/:projectId/scope-of-work/:scopeId', (req, res) => {
    const { userId } = req.body;
    const scopeItem = db.deleteScopeOfWork(req.params.projectId, req.params.scopeId, userId);
    if (scopeItem) {
        res.status(204).send();
    } else {
        res.status(404).send('Scope item not found');
    }
});


app.use('/api', apiRouter);

// --- STATIC FILE SERVING ---
// Serve static files from the 'dist' directory, which is Vite's build output
const distPath = path.join(__dirname, '..', 'dist');
app.use(express.static(distPath));

// For any other request, serve the index.html file from 'dist'
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});