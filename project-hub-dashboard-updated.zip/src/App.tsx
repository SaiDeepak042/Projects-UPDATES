import React, { useState, useEffect, useMemo, useCallback } from 'react';
import type { View, User, Project, Task, ClientInput, Meeting, TaskStatusName, Activity, Estimation, ScopeOfWork } from './types/index.ts';
import { ActivityActionType } from './types/index.ts';
import Login from './pages/Login.tsx';
import Sidebar from './components/Sidebar.tsx';
import Header from './components/Header.tsx';
import Dashboard from './pages/Dashboard.tsx';
import ProjectsPage from './pages/ProjectsPage.tsx';
import MyTasksPage from './pages/MyTasksPage.tsx';
import UsersPage from './pages/UsersPage.tsx';
import TemplatesPage from './pages/TemplatesPage.tsx';
import ProjectDashboard from './pages/ProjectDashboard.tsx';
import * as api from './api/index.ts';

// Modals
import CreateProjectModal from './components/modals/CreateProjectModal.tsx';
import EditProjectModal from './components/modals/EditProjectModal.tsx';
import ConfirmDeleteModal from './components/modals/ConfirmDeleteModal.tsx';
import CreateTaskModal from './components/modals/CreateTaskModal.tsx';
import CreateClientInputModal from './components/modals/CreateClientInputModal.tsx';
import CreateMeetingModal from './components/modals/CreateMeetingModal.tsx';
import CreateUserModal from './components/modals/CreateUserModal.tsx';
import TaskDetailModal from './components/modals/TaskDetailModal.tsx';
import CreateEstimationModal from './components/modals/CreateEstimationModal.tsx';
import EstimationHistoryModal from './components/modals/EstimationHistoryModal.tsx';
import CreateScopeOfWorkModal from './components/modals/CreateScopeOfWorkModal.tsx';


const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [allProjects, setAllProjects] = useState<Project[]>([]);
  
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const [isSidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Modal States
  const [isCreateProjectOpen, setCreateProjectOpen] = useState(false);
  const [isEditProjectOpen, setEditProjectOpen] = useState(false);
  const [isDeleteProjectOpen, setDeleteProjectOpen] = useState(false);
  const [projectToEdit, setProjectToEdit] = useState<Project | null>(null);
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);

  const [isCreateTaskOpen, setCreateTaskOpen] = useState(false);
  const [isEditTaskOpen, setEditTaskOpen] = useState(false);
  const [isDeleteTaskOpen, setDeleteTaskOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);
  const [defaultTaskStatus, setDefaultTaskStatus] = useState<TaskStatusName>('New');

  const [isCreateClientInputOpen, setCreateClientInputOpen] = useState(false);
  const [isEditClientInputOpen, setEditClientInputOpen] = useState(false);
  const [isDeleteClientInputOpen, setDeleteClientInputOpen] = useState(false);
  const [clientInputToEdit, setClientInputToEdit] = useState<ClientInput | null>(null);
  const [clientInputToDelete, setClientInputToDelete] = useState<ClientInput | null>(null);

  const [isCreateMeetingOpen, setCreateMeetingOpen] = useState(false);

  const [isCreateUserOpen, setCreateUserOpen] = useState(false);

  const [isTaskDetailOpen, setTaskDetailOpen] = useState(false);

  const [isCreateEstimationOpen, setCreateEstimationOpen] = useState(false);
  const [isEditEstimationOpen, setEditEstimationOpen] = useState(false);
  const [isDeleteEstimationOpen, setDeleteEstimationOpen] = useState(false);
  const [estimationToEdit, setEstimationToEdit] = useState<Estimation | null>(null);
  const [estimationToDelete, setEstimationToDelete] = useState<Estimation | null>(null);
  const [isEstimationHistoryOpen, setEstimationHistoryOpen] = useState(false);
  const [estimationForHistory, setEstimationForHistory] = useState<Estimation | null>(null);

  const [isCreateScopeOfWorkOpen, setCreateScopeOfWorkOpen] = useState(false);
  const [isEditScopeOfWorkOpen, setEditScopeOfWorkOpen] = useState(false);
  const [isDeleteScopeOfWorkOpen, setDeleteScopeOfWorkOpen] = useState(false);
  const [scopeOfWorkToEdit, setScopeOfWorkToEdit] = useState<ScopeOfWork | null>(null);
  const [scopeOfWorkToDelete, setScopeOfWorkToDelete] = useState<ScopeOfWork | null>(null);

  const fetchData = useCallback(async () => {
    try {
        const [usersData, projectsData] = await Promise.all([
            api.getUsers(),
            api.getProjects(),
        ]);
        
        setAllUsers(usersData);
        setAllProjects(projectsData);
        
        if (selectedProject) {
            const updatedSelectedProject = projectsData.find((p: Project) => p.id === selectedProject.id);
            setSelectedProject(updatedSelectedProject || null);
        }
    } catch (error) {
        console.error("Error fetching data:", error);
    }
  }, [selectedProject?.id]);
  
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    const lowPermissionDesignations = [
      'Junior Software Developer',
      'Trainee Design Automation Engineer',
      'Junior AI Programmer',
      'Junior Design Automation Engineer'
    ];
    if (lowPermissionDesignations.includes(user.designation)) {
      setCurrentView('tasks');
    } else {
      setCurrentView('dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('dashboard');
    setSelectedProject(null);
  };

  // Project Handlers
  const handleCreateProject = async (projectData: Omit<Project, 'id' | 'status' | 'progress'>) => {
    await api.createProject(projectData, currentUser!.id);
    fetchData();
    setCreateProjectOpen(false);
  };

  const handleUpdateProject = async (updatedProjectData: Project) => {
    await api.updateProject(updatedProjectData.id, updatedProjectData, currentUser!.id);
    fetchData();
    setEditProjectOpen(false);
    setProjectToEdit(null);
  };

  const handleDeleteProject = async () => {
    if (!projectToDelete) return;
    await api.deleteProject(projectToDelete.id);
    fetchData();
    setDeleteProjectOpen(false);
    setProjectToDelete(null);
    if (selectedProject?.id === projectToDelete.id) {
        setSelectedProject(null);
        setCurrentView('projects');
    }
  };

  // Task Handlers
  const handleSaveTask = async (taskData: Omit<Task, 'id' | 'createdOn' | 'updatedOn' | 'creatorId' | 'projectId' | 'projectName'>, idToUpdate?: string) => {
      if (!selectedProject || !currentUser) return;

      if (idToUpdate) { // Editing existing task
        await api.updateTask(selectedProject.id, idToUpdate, taskData, currentUser.id);
      } else { // Creating new task
        await api.createTask(selectedProject.id, taskData, currentUser.id);
      }

      fetchData();
      setCreateTaskOpen(false);
      setEditTaskOpen(false);
      setTaskToEdit(null);
  };

  const handleDeleteTask = async () => {
    if (!taskToDelete || !selectedProject || !currentUser) return;
    await api.deleteTask(selectedProject.id, taskToDelete.id, currentUser.id);
    fetchData();
    setDeleteTaskOpen(false);
    setTaskToDelete(null);
  };

  // Client Input Handlers
  const handleSaveClientInput = async (inputData: Omit<ClientInput, 'id' | 'files'> & { files?: File[] }, idToUpdate?: string) => {
    if (!selectedProject || !currentUser) return;
    const { files, ...restOfInputData } = inputData;
    const filesMetadata = (files || []).map(f => ({ name: f.name, url: '#' }));
    
    const payload = { ...restOfInputData, files: filesMetadata };

    if (idToUpdate) {
        await api.updateClientInput(selectedProject.id, idToUpdate, payload, currentUser.id);
    } else {
        await api.createClientInput(selectedProject.id, payload, currentUser.id);
    }

    fetchData();
    setCreateClientInputOpen(false);
    setEditClientInputOpen(false);
    setClientInputToEdit(null);
  };

  const handleDeleteClientInput = async () => {
    if (!clientInputToDelete || !selectedProject || !currentUser) return;
    await api.deleteClientInput(selectedProject.id, clientInputToDelete.id, currentUser.id);
    fetchData();
    setDeleteClientInputOpen(false);
    setClientInputToDelete(null);
  };

  // Meeting Handlers
  const handleCreateMeeting = async (meetingData: Omit<Meeting, 'id'>) => {
    if (!selectedProject || !currentUser) return;
    await api.createMeeting(selectedProject.id, meetingData, currentUser.id);
    fetchData();
    setCreateMeetingOpen(false);
  };
  
  // User Handlers
  // FIX: Updated the type of `userData` to match the data passed from the `CreateUserModal`. The modal passes `projects` as a string, not an array of strings, and does not pass an avatar.
  const handleCreateUser = async (userData: Omit<User, 'id' | 'avatar' | 'projects'> & { projects: string }) => {
      await api.createUser(userData);
      fetchData();
      setCreateUserOpen(false);
  };

    // Estimation Handlers
  const handleSaveEstimation = async (estimationData: Omit<Estimation, 'id' | 'createdOn' | 'updatedOn' | 'creatorId' | 'projectId'>, idToUpdate?: string) => {
    if (!selectedProject || !currentUser) return;

    if (idToUpdate) { // Editing existing
        await api.updateEstimation(selectedProject.id, idToUpdate, estimationData, currentUser.id);
    } else { // Creating new
        await api.createEstimation(selectedProject.id, estimationData, currentUser.id);
    }

    fetchData();
    setCreateEstimationOpen(false);
    setEditEstimationOpen(false);
    setEstimationToEdit(null);
  };

  const handleDeleteEstimation = async () => {
    if (!estimationToDelete || !selectedProject || !currentUser) return;
    await api.deleteEstimation(selectedProject.id, estimationToDelete.id, currentUser.id);
    fetchData();
    setDeleteEstimationOpen(false);
    setEstimationToDelete(null);
  };

  // Scope of Work Handlers
  const handleSaveScopeOfWork = async (scopeData: Omit<ScopeOfWork, 'id' | 'projectId'>, idToUpdate?: string) => {
    if (!selectedProject || !currentUser) return;
    if (idToUpdate) {
        await api.updateScopeOfWork(selectedProject.id, idToUpdate, scopeData, currentUser.id);
    } else {
        await api.createScopeOfWork(selectedProject.id, scopeData, currentUser.id);
    }
    fetchData();
    setCreateScopeOfWorkOpen(false);
    setEditScopeOfWorkOpen(false);
    setScopeOfWorkToEdit(null);
  };

  const handleDeleteScopeOfWork = async () => {
    if (!scopeOfWorkToDelete || !selectedProject || !currentUser) return;
    await api.deleteScopeOfWork(selectedProject.id, scopeOfWorkToDelete.id, currentUser.id);
    fetchData();
    setDeleteScopeOfWorkOpen(false);
    setScopeOfWorkToDelete(null);
  };

  const pageTitle = useMemo(() => {
    if (selectedProject) return selectedProject.name;
    switch (currentView) {
      case 'dashboard': return 'Dashboard';
      case 'projects': return 'Projects';
      case 'tasks': return 'My Tasks';
      case 'users': return 'Users';
      case 'templates': return 'Templates';
      default: return 'Project Hub';
    }
  }, [currentView, selectedProject]);
  
  const handleViewProject = (project: Project) => {
    setSelectedProject(project);
    setCurrentView('project-detail');
  };

  const handleViewTask = (task: Task) => {
    const projectForTask = allProjects.find(p => p.id === task.projectId);
    if(projectForTask){
        setSelectedProject(projectForTask);
        setSelectedTask(task);
        setTaskDetailOpen(true);
    }
  };

  if (!currentUser) {
    return <Login onLogin={handleLogin} users={allUsers} />;
  }

  const renderContent = () => {
    if (selectedProject && currentView === 'project-detail') {
      return (
        <ProjectDashboard
          project={selectedProject}
          allUsers={allUsers}
          currentUser={currentUser}
          onBack={() => {
            setSelectedProject(null);
            setCurrentView('projects');
          }}
          onViewTask={handleViewTask}
          onOpenCreateTask={() => setCreateTaskOpen(true)}
          onOpenEditTask={(task) => { setTaskToEdit(task); setEditTaskOpen(true); }}
          onOpenDeleteTask={(task) => { setTaskToDelete(task); setDeleteTaskOpen(true); }}
          onOpenCreateClientInput={() => setCreateClientInputOpen(true)}
          onOpenEditClientInput={(input) => { setClientInputToEdit(input); setEditClientInputOpen(true); }}
          onOpenDeleteClientInput={(input) => { setClientInputToDelete(input); setDeleteClientInputOpen(true); }}
          onOpenCreateMeeting={() => setCreateMeetingOpen(true)}
          onOpenCreateEstimation={() => setCreateEstimationOpen(true)}
          onOpenEditEstimation={(estimation) => { setEstimationToEdit(estimation); setEditEstimationOpen(true); }}
          onOpenDeleteEstimation={(estimation) => { setEstimationToDelete(estimation); setDeleteEstimationOpen(true); }}
          onOpenEstimationHistory={(estimation) => { setEstimationForHistory(estimation); setEstimationHistoryOpen(true); }}
          onOpenCreateScopeOfWork={() => setCreateScopeOfWorkOpen(true)}
          onOpenEditScopeOfWork={(scope) => { setScopeOfWorkToEdit(scope); setEditScopeOfWorkOpen(true); }}
          onOpenDeleteScopeOfWork={(scope) => { setScopeOfWorkToDelete(scope); setDeleteScopeOfWorkOpen(true); }}
        />
      );
    }

    switch (currentView) {
      case 'dashboard':
        return <Dashboard 
            projects={allProjects} 
            allUsers={allUsers} 
            currentUser={currentUser} 
            onViewChange={setCurrentView} 
            onViewProject={handleViewProject}
        />;
      case 'projects':
        return <ProjectsPage 
            projects={allProjects} 
            currentUser={currentUser} 
            onOpenCreate={() => setCreateProjectOpen(true)} 
            onOpenEdit={(project) => {setProjectToEdit(project); setEditProjectOpen(true);}} 
            onOpenDelete={(project) => {setProjectToDelete(project); setDeleteProjectOpen(true);}}
            onViewProject={handleViewProject}
        />;
      case 'tasks':
        return <MyTasksPage projects={allProjects} currentUser={currentUser} allUsers={allUsers} onViewTask={handleViewTask} />;
      case 'users':
        return <UsersPage allUsers={allUsers} currentUser={currentUser} onOpenCreate={() => setCreateUserOpen(true)} />;
      case 'templates':
        return <TemplatesPage />;
      default:
        return <div>Not Found</div>;
    }
  };

  return (
    <div className="flex h-screen bg-background text-text-primary">
      <Sidebar
        currentView={currentView}
        onViewChange={(view) => {
          setCurrentView(view);
          setSelectedProject(null); // Reset project view when changing main view
        }}
        currentUser={currentUser}
        onLogout={handleLogout}
        isCollapsed={isSidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!isSidebarCollapsed)}
      />
      <main className={`flex-1 flex flex-col transition-all duration-300 ease-in-out ${isSidebarCollapsed ? 'ml-20' : 'ml-64'}`}>
        <Header currentUser={currentUser} pageTitle={pageTitle} />
        <div className="flex-1 p-6 overflow-y-auto">
            {renderContent()}
        </div>
      </main>

      {/* Modals */}
      <CreateProjectModal 
        isOpen={isCreateProjectOpen} 
        onClose={() => setCreateProjectOpen(false)} 
        onCreateProject={handleCreateProject}
        currentUser={currentUser}
      />
      {projectToEdit && (
        <EditProjectModal 
            isOpen={isEditProjectOpen}
            onClose={() => {setEditProjectOpen(false); setProjectToEdit(null);}}
            onUpdateProject={handleUpdateProject}
            project={projectToEdit}
        />
      )}
      {projectToDelete && (
        <ConfirmDeleteModal
            isOpen={isDeleteProjectOpen}
            onClose={() => {setDeleteProjectOpen(false); setProjectToDelete(null);}}
            onConfirm={handleDeleteProject}
            itemName={projectToDelete.name}
            itemType="project"
        />
      )}
      {(isCreateTaskOpen || isEditTaskOpen) && selectedProject && (
          <CreateTaskModal
            isOpen={isCreateTaskOpen || isEditTaskOpen}
            onClose={() => { setCreateTaskOpen(false); setEditTaskOpen(false); setTaskToEdit(null);}}
            onSave={handleSaveTask}
            taskToEdit={taskToEdit}
            teamMembers={allUsers.filter(u => selectedProject.teamMemberIds.includes(u.id))}
            defaultTaskStatus={defaultTaskStatus}
          />
      )}
      {taskToDelete && (
          <ConfirmDeleteModal
            isOpen={isDeleteTaskOpen}
            onClose={() => {setDeleteTaskOpen(false); setTaskToDelete(null);}}
            onConfirm={handleDeleteTask}
            itemName={taskToDelete.title}
            itemType="task"
          />
      )}
       {(isCreateClientInputOpen || isEditClientInputOpen) && (
        <CreateClientInputModal
            isOpen={isCreateClientInputOpen || isEditClientInputOpen}
            onClose={() => { setCreateClientInputOpen(false); setEditClientInputOpen(false); setClientInputToEdit(null); }}
            onSave={handleSaveClientInput}
            inputToEdit={clientInputToEdit}
        />
       )}
       {clientInputToDelete && (
         <ConfirmDeleteModal
            isOpen={isDeleteClientInputOpen}
            onClose={() => {setDeleteClientInputOpen(false); setClientInputToDelete(null);}}
            onConfirm={handleDeleteClientInput}
            itemName={clientInputToDelete.description}
            itemType="client input request"
         />
       )}
       {isCreateMeetingOpen && selectedProject && (
        <CreateMeetingModal
            isOpen={isCreateMeetingOpen}
            onClose={() => setCreateMeetingOpen(false)}
            onCreate={handleCreateMeeting}
            teamMembers={allUsers.filter(u => selectedProject.teamMemberIds.includes(u.id))}
        />
       )}
       {isCreateUserOpen && (
           <CreateUserModal
                isOpen={isCreateUserOpen}
                onClose={() => setCreateUserOpen(false)}
                onCreateUser={handleCreateUser}
           />
       )}
       {isTaskDetailOpen && selectedTask && (
           <TaskDetailModal
                isOpen={isTaskDetailOpen}
                onClose={() => {setTaskDetailOpen(false); setSelectedTask(null);}}
                task={selectedTask}
                project={selectedProject}
                users={allUsers}
           />
       )}
       {(isCreateEstimationOpen || isEditEstimationOpen) && (
        <CreateEstimationModal
            isOpen={isCreateEstimationOpen || isEditEstimationOpen}
            onClose={() => { setCreateEstimationOpen(false); setEditEstimationOpen(false); setEstimationToEdit(null); }}
            onSave={handleSaveEstimation}
            estimationToEdit={estimationToEdit}
        />
       )}
       {estimationToDelete && (
        <ConfirmDeleteModal
            isOpen={isDeleteEstimationOpen}
            onClose={() => { setDeleteEstimationOpen(false); setEstimationToDelete(null); }}
            onConfirm={handleDeleteEstimation}
            itemName={`${estimationToDelete.featureTask} - ${estimationToDelete.subtask}`}
            itemType="estimation"
        />
       )}
       {isEstimationHistoryOpen && estimationForHistory && selectedProject && (
        <EstimationHistoryModal
            isOpen={isEstimationHistoryOpen}
            onClose={() => { setEstimationHistoryOpen(false); setEstimationForHistory(null); }}
            estimation={estimationForHistory}
            projectActivities={selectedProject.activities}
            allUsers={allUsers}
        />
       )}
       {(isCreateScopeOfWorkOpen || isEditScopeOfWorkOpen) && selectedProject && (
        <CreateScopeOfWorkModal
            isOpen={isCreateScopeOfWorkOpen || isEditScopeOfWorkOpen}
            onClose={() => { setCreateScopeOfWorkOpen(false); setEditScopeOfWorkOpen(false); setScopeOfWorkToEdit(null); }}
            onSave={handleSaveScopeOfWork}
            scopeToEdit={scopeOfWorkToEdit}
            teamMembers={allUsers.filter(u => selectedProject.teamMemberIds.includes(u.id))}
        />
       )}
        {scopeOfWorkToDelete && (
        <ConfirmDeleteModal
            isOpen={isDeleteScopeOfWorkOpen}
            onClose={() => { setDeleteScopeOfWorkOpen(false); setScopeOfWorkToDelete(null); }}
            onConfirm={handleDeleteScopeOfWork}
            itemName={`${scopeOfWorkToDelete.featureModule} - ${scopeOfWorkToDelete.taskSubtask}`}
            itemType="scope of work item"
        />
       )}
    </div>
  );
};

export default App;