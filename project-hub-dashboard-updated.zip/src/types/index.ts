import { ActivityActionType as ActionTypeEnum } from '../../shared/ActivityActionType.js';

// Re-export the enum value for use in application logic.
export const ActivityActionType = ActionTypeEnum;

// Create a TypeScript type from the object's values for type safety.
export type ActivityActionType = (typeof ActionTypeEnum)[keyof typeof ActionTypeEnum];


export type View = 'dashboard' | 'projects' | 'project-detail' | 'tasks' | 'users' | 'templates';

export interface User {
  id: string;
  name: string;
  email: string;
  designation: string;
  department: string;
  projects: string[];
  avatar: string;
}

export type ProjectStatus = 'In Progress' | 'Completed' | 'On Hold' | 'Cancelled';

export interface Project {
  id:string;
  name: string;
  description: string;
  leaderId: string;
  teamMemberIds: string[];
  dueDate: string; // ISO string
  status: ProjectStatus;
  progress: number;
  tasks: Task[];
  activities: Activity[];
  clientInputs: ClientInput[];
  meetings: Meeting[];
  estimations: Estimation[];
  scopeOfWork: ScopeOfWork[];
}

export type TaskStatusName = 'New' | 'To Do' | 'In Progress' | 'Review' | 'Done';
export type TaskPriority = 'Low' | 'Normal' | 'Medium' | 'High';

export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatusName;
  priority: TaskPriority;
  dueDate: string; // ISO string
  assigneeId: string;
  creatorId: string;
  createdOn: string; // ISO string
  updatedOn: string; // ISO string
  type: 'Bug' | 'Feature' | 'Task';
  category?: string;
  projectId?: string;
  projectName?: string;
}

export interface Activity {
  id: string;
  userId: string;
  actionType: ActivityActionType;
  timestamp: string; // ISO string
  details: {
    projectName?: string;
    taskTitle?: string;
    inputDescription?: string;
    meetingTitle?: string;
    estimationTitle?: string;
    estimationId?: string;
    scopeTitle?: string;
    [key: string]: any;
  };
}

export type ClientInputStatus = 'Pending' | 'Completed' | 'On Hold';

export interface ClientInput {
  id: string;
  description: string;
  requestedOn: string; // ISO string
  requestedBy: string; 
  receivedOn?: string; // ISO string
  hasReceived: boolean;
  assignee?: string; 
  status: ClientInputStatus;
  files: { name: string; url: string }[];
}

export interface Meeting {
  id: string;
  title: string;
  date: string; // ISO string YYYY-MM-DD
  time: string; // HH:mm
  attendees: string[]; // array of user IDs
}

export type EstimationComplexity = 'Low' | 'Medium' | 'High';
export type EstimationRisk = 'Low' | 'Medium' | 'High';
export type EstimationPriority = 'Low' | 'Medium' | 'High';
export type EstimationProjectType = 'Web' | 'CAD' | 'Both' | 'CAD + Web' | 'CAD Plugin';

export interface Estimation {
  id: string;
  projectId: string;
  phase: string;
  projectType: EstimationProjectType;
  featureTask: string;
  subtask: string;
  complexity: EstimationComplexity;
  estimatedHours: number;
  dependencies: string;
  developerNotes: string;
  riskLevel: EstimationRisk;
  technologyStack: string;
  priority: EstimationPriority;
  createdOn: string; // ISO string
  updatedOn: string; // ISO string
  creatorId: string;
}

export interface ScopeOfWork {
    id: string;
    projectId: string;
    scopeOfWork: string;
    featureModule: string;
    taskSubtask: string;
    description: string;
    deliverables: string;
    acceptanceCriteria: string;
    estimatedEffort: number;
    dependencies: string;
    responsibleParty: string; // userId
    priority: EstimationPriority;
    riskLevel: EstimationRisk;
    notes: string;
}