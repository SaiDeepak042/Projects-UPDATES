import React from 'react';
import type { Project, User, View } from '../types/index.ts';
import StatCard from '../components/StatCard.tsx';
import ProjectList from '../components/ProjectList.tsx';
import ActivityFeed from '../components/ActivityFeed.tsx';
import TeamOverview from '../components/TeamOverview.tsx';
import { ProjectsIcon } from '../components/icons/ProjectsIcon.tsx';
import { TasksIcon } from '../components/icons/TasksIcon.tsx';
import { TeamsIcon } from '../components/icons/TeamsIcon.tsx';
import { CheckCircleIcon } from '../components/icons/CheckCircleIcon.tsx';

interface DashboardProps {
  projects: Project[];
  allUsers: User[];
  currentUser: User;
  onViewChange: (view: View) => void;
  onViewProject: (project: Project) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ projects, allUsers, currentUser, onViewChange, onViewProject }) => {

  const activeProjects = projects.filter(p => p.status === 'In Progress');
  const completedProjects = projects.filter(p => p.status === 'Completed');
  const allTasks = projects.flatMap(p => p.tasks);
  const myTasks = allTasks.filter(t => t.assigneeId === currentUser.id);
  const recentActivities = projects.flatMap(p => p.activities).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10);
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <StatCard 
          title="Active Projects"
          value={activeProjects.length.toString()}
          icon={<ProjectsIcon className="w-6 h-6" />}
        />
        <StatCard 
          title="My Pending Tasks"
          value={myTasks.filter(t => t.status !== 'Done').length.toString()}
          icon={<TasksIcon className="w-6 h-6" />}
        />
         <StatCard 
          title="Projects Completed"
          value={completedProjects.length.toString()}
          icon={<CheckCircleIcon className="w-6 h-6" />}
        />
        <StatCard 
          title="Team Members"
          value={allUsers.length.toString()}
          icon={<TeamsIcon className="w-6 h-6" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <div className="lg:col-span-3">
            <ProjectList 
                projects={projects.slice(0, 5)} 
                onViewChange={onViewChange}
                onViewProject={onViewProject}
             />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          <div className="lg:col-span-2">
              <ActivityFeed activities={recentActivities} allUsers={allUsers} title="Recent Activity" />
          </div>
          <div>
              <TeamOverview users={allUsers} projects={projects} onViewChange={onViewChange} />
          </div>
      </div>
    </div>
  );
};

export default Dashboard;