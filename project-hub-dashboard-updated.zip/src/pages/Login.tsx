import React, { useState } from 'react';
import type { User } from '../types/index.ts';

interface LoginProps {
  onLogin: (user: User) => void;
  users: User[];
}

const Login: React.FC<LoginProps> = ({ onLogin, users }) => {
  const [selectedUserId, setSelectedUserId] = useState<string | null>(users[0]?.id || null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId) return;
    const userToLogin = users.find(u => u.id === selectedUserId);
    if (userToLogin) {
      onLogin(userToLogin);
    }
  };
  
  const selectedUser = users.find(u => u.id === selectedUserId);

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-100 p-4">
      <div className="w-full max-w-lg p-8 space-y-8 bg-card rounded-2xl shadow-card border border-border">
        <div className="text-center">
            <div className="mx-auto w-12 h-12 bg-primary rounded-xl flex items-center justify-center font-bold text-2xl text-white mb-4">
                PH
            </div>
            <h2 className="text-2xl font-bold text-text-primary">
                Welcome to Project Hub
            </h2>
            <p className="text-text-secondary mt-2">Please select a user profile to sign in.</p>
        </div>
        <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-3">
                <label className="block text-sm font-medium text-text-primary">Select your profile</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-60 overflow-y-auto pr-2">
                    {users.map(user => (
                        <div 
                            key={user.id}
                            onClick={() => setSelectedUserId(user.id)}
                            className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                                selectedUserId === user.id 
                                ? 'border-primary bg-primary/5' 
                                : 'border-border hover:border-primary/50'
                            }`}
                        >
                            <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                            <div>
                                <p className="font-semibold text-sm text-text-primary">{user.name}</p>
                                <p className="text-xs text-text-secondary">{user.designation}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

          <div>
            <button
              type="submit"
              disabled={!selectedUserId}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-card focus:ring-primary transition-colors disabled:bg-primary/50 disabled:cursor-not-allowed"
            >
              Sign in as {selectedUser?.name.split(' ')[0] || '...'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;