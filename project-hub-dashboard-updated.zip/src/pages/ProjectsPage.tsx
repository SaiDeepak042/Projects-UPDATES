import React, { useState, useMemo } from 'react';
import type { Project, User } from '../types/index.ts';
import ProjectCard from '../components/ProjectCard.tsx';
import { PlusIcon } from '../components/icons/PlusIcon.tsx';
import { SearchIcon } from '../components/icons/SearchIcon.tsx';

interface ProjectsPageProps {
  projects: Project[];
  currentUser: User;
  onOpenCreate: () => void;
  onOpenEdit: (project: Project) => void;
  onOpenDelete: (project: Project) => void;
  onViewProject: (project: Project) => void;
}

type SortKey = 'name' | 'status' | 'dueDate';

const ProjectsPage: React.FC<ProjectsPageProps> = ({ projects, currentUser, onOpenCreate, onOpenEdit, onOpenDelete, onViewProject }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('dueDate');

  const canSeeAll = new Set(['Director', 'HR Generalist']).has(currentUser.designation);
  const canCreate = new Set(['Director', 'Software Developer', 'Design Automation Specialist', 'Product Configurator Specialist']).has(currentUser.designation);

  const projectsForUser = canSeeAll
      ? projects
      : projects.filter(p =>
          p.teamMemberIds.includes(currentUser.id) || p.leaderId === currentUser.id
        );
        
  const sortedAndFilteredProjects = useMemo(() => {
    const filtered = projectsForUser.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    
    return filtered.sort((a, b) => {
        if (a[sortKey] < b[sortKey]) return -1;
        if (a[sortKey] > b[sortKey]) return 1;
        return 0;
    });
  }, [projectsForUser, searchTerm, sortKey]);


  return (
    <div>
      <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
        <div className="relative w-full sm:w-auto sm:max-w-sm flex-grow">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-tertiary" />
          <input
            type="text"
            placeholder="Search by project name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-card border border-border rounded-lg pl-11 pr-4 py-2.5 text-sm text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition w-full"
          />
        </div>
        <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
                <label htmlFor="sort-projects" className="text-sm font-medium text-text-secondary">Sort by:</label>
                <select 
                    id="sort-projects"
                    value={sortKey}
                    onChange={(e) => setSortKey(e.target.value as SortKey)}
                    className="bg-card border border-border rounded-lg px-3 py-2 text-sm text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition"
                >
                    <option value="dueDate">Due Date</option>
                    <option value="name">Name</option>
                    <option value="status">Status</option>
                </select>
            </div>
            {canCreate && (
            <button
                onClick={onOpenCreate}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-primary rounded-lg hover:bg-primary-hover transition-colors"
            >
                <PlusIcon className="w-5 h-5" />
                Create Project
            </button>
            )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {sortedAndFilteredProjects.length > 0 ? sortedAndFilteredProjects.map(project => (
          <ProjectCard 
            key={project.id} 
            project={project} 
            currentUser={currentUser}
            onDelete={() => onOpenDelete(project)}
            onView={() => onViewProject(project)}
            onEdit={() => onOpenEdit(project)}
          />
        )) : (
          <div className="md:col-span-2 lg:col-span-3 xl:col-span-4 text-center py-16 text-text-secondary">
            <p>No projects found.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectsPage;
