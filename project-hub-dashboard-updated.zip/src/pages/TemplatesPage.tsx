import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card.tsx';
import { Button } from '../components/ui/button.tsx';
import { FileDocxIcon } from '../components/icons/FileDocxIcon.tsx';
import { FileXlsxIcon } from '../components/icons/FileXlsxIcon.tsx';
import { FilePptIcon } from '../components/icons/FilePptIcon.tsx';
import { DownloadIcon } from '../components/icons/DownloadIcon.tsx';

const templates = [
  {
    name: 'Scope of Work',
    description: 'A detailed document outlining project objectives, deliverables, timelines, and milestones.',
    fileName: 'scope of work.docx',
    icon: <FileDocxIcon className="w-16 h-16" />,
  },
  {
    name: 'Project Estimation',
    description: 'A spreadsheet for estimating project costs, resources, and timelines.',
    fileName: 'project estimation.xlsx',
    icon: <FileXlsxIcon className="w-16 h-16" />,
  },
  {
    name: 'Presentation Template',
    description: 'A ready-to-use slide deck for project proposals, kick-offs, or status updates.',
    fileName: 'presentation template.ppt',
    icon: <FilePptIcon className="w-16 h-16" />,
  },
];

const TemplatesPage: React.FC = () => {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-text-primary">Templates Library</h1>
        <p className="text-text-secondary mt-1">Download ready-to-use templates to streamline your project management process.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map((template) => (
          <Card key={template.fileName} className="flex flex-col">
            <CardHeader className="items-center text-center">
              {template.icon}
              <CardTitle className="mt-4">{template.name}</CardTitle>
              <CardDescription>{template.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow flex items-end justify-center">
              <a
                href={`/templates/${template.fileName.replace(/ /g, '%20')}`}
                download
                className="w-full"
              >
                <Button className="w-full" variant="outline">
                  <DownloadIcon className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </a>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default TemplatesPage;
