import React, { useState, useMemo } from 'react';
import type { Project, Task, User, TaskPriority, TaskStatusName } from '../types/index.ts';
import { ArrowUpIcon } from '../components/icons/ArrowUpIcon.tsx';
import { ArrowDownIcon } from '../components/icons/ArrowDownIcon.tsx';
import { SortIcon } from '../components/icons/SortIcon.tsx';

interface MyTasksPageProps {
  projects: Project[];
  currentUser: User;
  allUsers: User[];
  onViewTask: (task: Task) => void;
}

type SortableTaskKeys = 'title' | 'priority' | 'dueDate' | 'projectName';

const COLORS = ['#22c55e', '#ef4444', '#f97316', '#3b82fd', '#6366f1', '#a855f7', '#ec4899', '#14b8a6'];

const getAvatarInfo = (name: string) => {
    const initials = name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
    const charCodeSum = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const color = COLORS[charCodeSum % COLORS.length];
    return { initials, color };
};

const getPriorityClass = (priority: TaskPriority) => {
    switch(priority) {
        case 'High': return 'text-red-600';
        case 'Medium': return 'text-amber-600';
        case 'Low': return 'text-blue-600';
        case 'Normal': return 'text-text-primary';
        default: return 'text-text-primary';
    }
};

const getStatusClass = (status: TaskStatusName) => {
    switch(status) {
        case 'To Do': return 'bg-slate-100 text-slate-700';
        case 'In Progress': return 'bg-blue-100 text-blue-700';
        case 'Review': return 'bg-amber-100 text-amber-700';
        case 'Done': return 'bg-green-100 text-green-700';
        case 'New': return 'bg-indigo-100 text-indigo-700';
        default: return 'bg-slate-100 text-slate-700';
    }
}

const MyTasksPage: React.FC<MyTasksPageProps> = ({ projects, currentUser, allUsers, onViewTask }) => {
  const [sortConfig, setSortConfig] = useState<{ key: SortableTaskKeys; direction: 'ascending' | 'descending' } | null>({ key: 'dueDate', direction: 'ascending' });
  const [filters, setFilters] = useState({ projectId: '', status: '' });

  const myTasks = useMemo(() => projects
    .flatMap(project =>
      (project.tasks || []).map(task => ({
        ...task,
        projectName: project.name,
        projectId: project.id,
      }))
    )
    .filter(task => task.assigneeId === currentUser.id), [projects, currentUser.id]);
  
  const userProjects = useMemo(() => 
    projects.filter(p => p.teamMemberIds.includes(currentUser.id)), 
    [projects, currentUser.id]
  );

  const getAssignee = (assigneeId: string) => allUsers.find(u => u.id === assigneeId);

  const sortedAndFilteredTasks = useMemo(() => {
    let sortableItems = [...myTasks];
    
    // Filtering
    if (filters.projectId) {
        sortableItems = sortableItems.filter(task => task.projectId === filters.projectId);
    }
    if (filters.status) {
        sortableItems = sortableItems.filter(task => task.status === filters.status);
    }

    // Sorting
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        if (sortConfig.key === 'priority') {
          const priorityOrder: Record<TaskPriority, number> = { 'High': 3, 'Medium': 2, 'Normal': 1, 'Low': 0 };
          const aValue = priorityOrder[a.priority];
          const bValue = priorityOrder[b.priority];
          if (aValue < bValue) return sortConfig.direction === 'ascending' ? -1 : 1;
          if (aValue > bValue) return sortConfig.direction === 'ascending' ? 1 : -1;
          return 0;
        }

        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        if (aValue < bValue) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [myTasks, sortConfig, filters]);

  const requestSort = (key: SortableTaskKeys) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key: SortableTaskKeys) => {
      if (!sortConfig || sortConfig.key !== key) {
          return <SortIcon className="w-4 h-4" />;
      }
      return sortConfig.direction === 'ascending' ? <ArrowUpIcon className="w-4 h-4" /> : <ArrowDownIcon className="w-4 h-4" />;
  }
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const { name, value } = e.target;
      setFilters(prev => ({...prev, [name]: value}));
  }

  return (
    <div className="space-y-4">
      <div className="bg-card p-4 rounded-2xl border border-border shadow-card flex items-center gap-4">
        <div className="flex items-center gap-2">
            <label htmlFor="project-filter" className="text-sm font-medium text-text-secondary">Project:</label>
            <select name="projectId" id="project-filter" value={filters.projectId} onChange={handleFilterChange} className="bg-background border border-border rounded-lg px-3 py-1.5 text-sm">
                <option value="">All Projects</option>
                {userProjects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
        </div>
        <div className="flex items-center gap-2">
            <label htmlFor="status-filter" className="text-sm font-medium text-text-secondary">Status:</label>
            <select name="status" id="status-filter" value={filters.status} onChange={handleFilterChange} className="bg-background border border-border rounded-lg px-3 py-1.5 text-sm">
                <option value="">All Statuses</option>
                <option>New</option>
                <option>To Do</option>
                <option>In Progress</option>
                <option>Review</option>
                <option>Done</option>
            </select>
        </div>
      </div>
      <div className="bg-card rounded-2xl border border-border shadow-card">
         <div className="overflow-x-auto">
             <table className="w-full text-left">
                <thead className="border-b border-border">
                    <tr>
                        <th className="p-4 text-xs font-semibold text-text-secondary uppercase tracking-wider w-16">ID</th>
                        <th className="p-4 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('title')}>
                            <div className="flex items-center gap-1">SUBJECT {getSortIcon('title')}</div>
                        </th>
                        <th className="p-4 text-xs font-semibold text-text-secondary uppercase tracking-wider whitespace-nowrap">TYPE</th>
                        <th className="p-4 text-xs font-semibold text-text-secondary uppercase tracking-wider whitespace-nowrap">STATUS</th>
                        <th className="p-4 text-xs font-semibold text-text-secondary uppercase tracking-wider whitespace-nowrap">ASSIGNEE</th>
                        <th className="p-4 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('priority')}>
                            <div className="flex items-center gap-1">PRIORITY {getSortIcon('priority')}</div>
                        </th>
                        <th className="p-4 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('dueDate')}>
                           <div className="flex items-center gap-1">DUE DATE {getSortIcon('dueDate')}</div>
                        </th>
                        <th className="p-4 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('projectName')}>
                           <div className="flex items-center gap-1">PROJECT NAME {getSortIcon('projectName')}</div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {sortedAndFilteredTasks.length > 0 ? sortedAndFilteredTasks.map((task) => {
                        const assignee = getAssignee(task.assigneeId);
                        const avatarInfo = assignee ? getAvatarInfo(assignee.name) : {initials: '?', color: '#94a3b8'};

                        return (
                            <tr key={task.id} className="border-b border-border last:border-0 hover:bg-slate-50 transition-colors cursor-pointer" onClick={() => onViewTask(task)}>
                                <td className="p-4 text-primary font-medium text-sm">{task.id.replace(/\D/g, '').slice(-3)}</td>
                                <td className="p-4 text-text-primary font-semibold text-sm">{task.title}</td>
                                <td className="p-4 text-orange-600 font-semibold text-xs">{task.type}</td>
                                <td className="p-4 text-text-primary text-sm">
                                  <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${getStatusClass(task.status)}`}>
                                    {task.status}
                                  </span>
                                </td>
                                <td className="p-4">
                                    {assignee && (
                                        <div className="flex items-center gap-2">
                                            <div style={{ backgroundColor: avatarInfo.color }} className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold">
                                                {avatarInfo.initials}
                                            </div>
                                            <span className="text-text-primary text-sm">{assignee.name}</span>
                                        </div>
                                    )}
                                </td>
                                <td className={`p-4 text-sm font-medium ${getPriorityClass(task.priority)}`}>{task.priority}</td>
                                <td className="p-4 text-text-secondary text-sm whitespace-nowrap">{new Date(task.dueDate).toLocaleDateString()}</td>
                                <td className="p-4 text-text-secondary text-sm">{task.projectName || '-'}</td>
                            </tr>
                        );
                    }) : (
                      <tr>
                        <td colSpan={8} className="text-center py-16 text-text-secondary">
                          You have no assigned tasks that match the current filters.
                        </td>
                      </tr>
                    )}
                </tbody>
             </table>
         </div>
      </div>
    </div>
  );
};

export default MyTasksPage;
