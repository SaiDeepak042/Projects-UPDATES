import React from 'react';
import type { User } from '../types/index.ts';
import { PlusIcon } from '../components/icons/PlusIcon.tsx';

interface UsersPageProps {
  allUsers: User[];
  currentUser: User;
  onOpenCreate: () => void;
}

const UsersPage: React.FC<UsersPageProps> = ({ allUsers, currentUser, onOpenCreate }) => {
  const canCreate = new Set(['Director']).has(currentUser.designation);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-text-primary">User Management</h1>
        {canCreate && (
          <button
            onClick={onOpenCreate}
            className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-primary rounded-lg hover:bg-indigo-700 transition"
          >
            <PlusIcon className="w-5 h-5" />
            Add User
          </button>
        )}
      </div>

      <div className="bg-card rounded-xl border border-border">
         <div className="overflow-x-auto">
             <table className="w-full text-left">
                <thead>
                    <tr className="border-b border-border">
                        <th className="p-4 text-sm font-semibold text-text-secondary">Name</th>
                        <th className="p-4 text-sm font-semibold text-text-secondary">Designation</th>
                        <th className="p-4 text-sm font-semibold text-text-secondary">Department</th>
                        <th className="p-4 text-sm font-semibold text-text-secondary">Email</th>
                        <th className="p-4 text-sm font-semibold text-text-secondary">Project(s)</th>
                        <th className="p-4 text-sm font-semibold text-text-secondary">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {allUsers.map(user => (
                    <tr key={user.id} className="border-b border-border last:border-0 hover:bg-slate-50 transition-colors">
                        <td className="p-4">
                            <div className="flex items-center gap-3">
                                <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                                <span className="font-medium text-text-primary">{user.name}</span>
                            </div>
                        </td>
                        <td className="p-4 text-sm text-text-primary">{user.designation}</td>
                        <td className="p-4 text-sm text-text-primary">{user.department}</td>
                        <td className="p-4 text-sm text-text-primary">{user.email}</td>
                        <td className="p-4 text-sm text-text-primary">{user.projects.join(', ') || '—'}</td>
                         <td className="p-4">
                            <button className="text-sm text-primary/50 cursor-not-allowed" disabled title="Edit not available">Edit</button>
                        </td>
                    </tr>
                    ))}
                </tbody>
             </table>
         </div>
      </div>
    </div>
  );
};

export default UsersPage;