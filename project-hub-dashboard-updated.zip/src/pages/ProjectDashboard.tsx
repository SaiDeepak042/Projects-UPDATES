import React, { useState, useMemo } from 'react';
import type { Project, User, Task, ClientInput, Meeting, Estimation, ScopeOfWork, TaskStatusName } from '../types/index.ts';
import ProjectHeader from '../components/ProjectHeader.tsx';
import ProjectTeamCard from '../components/ProjectTeamCard.tsx';
import ProjectTasks from '../components/ProjectTasks.tsx';
import ClientInputsList from '../components/ClientInputsList.tsx';
import MeetingsList from '../components/MeetingsList.tsx';
import ActivityFeed from '../components/ActivityFeed.tsx';
import ProjectEstimations from '../components/ProjectEstimations.tsx';
import ScopeOfWorkList from '../components/ScopeOfWorkList.tsx';

interface ProjectDashboardProps {
  project: Project;
  allUsers: User[];
  currentUser: User;
  onBack: () => void;
  onViewTask: (task: Task) => void;
  onOpenCreateTask: () => void;
  onOpenEditTask: (task: Task) => void;
  onOpenDeleteTask: (task: Task) => void;
  onOpenCreateClientInput: () => void;
  onOpenEditClientInput: (input: ClientInput) => void;
  onOpenDeleteClientInput: (input: ClientInput) => void;
  onOpenCreateMeeting: () => void;
  onOpenCreateEstimation: () => void;
  onOpenEditEstimation: (estimation: Estimation) => void;
  onOpenDeleteEstimation: (estimation: Estimation) => void;
  onOpenEstimationHistory: (estimation: Estimation) => void;
  onOpenCreateScopeOfWork: () => void;
  onOpenEditScopeOfWork: (scope: ScopeOfWork) => void;
  onOpenDeleteScopeOfWork: (scope: ScopeOfWork) => void;
}

type ProjectView = 'tasks' | 'inputs' | 'meetings' | 'estimations' | 'scope-of-work';

type SortConfig<T> = { key: keyof T; direction: 'ascending' | 'descending' } | null;

// FIX: Define specific sortable keys to match child components and resolve type errors.
type SortableTaskKeys = 'title' | 'assigneeId' | 'priority' | 'dueDate';
type SortableClientInputKeys = 'requestedOn' | 'requestedBy' | 'status';

const ProjectDashboard: React.FC<ProjectDashboardProps> = (props) => {
  const { 
    project, allUsers, onBack, onViewTask, onOpenCreateTask, onOpenEditTask, onOpenDeleteTask, 
    onOpenCreateClientInput, onOpenEditClientInput, onOpenDeleteClientInput, onOpenCreateMeeting,
    onOpenCreateEstimation, onOpenEditEstimation, onOpenDeleteEstimation, onOpenEstimationHistory,
    onOpenCreateScopeOfWork, onOpenEditScopeOfWork, onOpenDeleteScopeOfWork
  } = props;
  const [activeView, setActiveView] = useState<ProjectView>('scope-of-work');

  // State for sorting and filtering
  const [scopeSortConfig, setScopeSortConfig] = useState<SortConfig<ScopeOfWork>>({ key: 'featureModule', direction: 'ascending'});
  const [scopeFilters, setScopeFilters] = useState({ responsibleParty: '' });
  
  // FIX: Use specific sortable keys type for taskSortConfig state to match the prop type in ProjectTasks.
  const [taskSortConfig, setTaskSortConfig] = useState<{ key: SortableTaskKeys; direction: 'ascending' | 'descending' } | null>({ key: 'dueDate', direction: 'ascending' });
  // FIX: Changed status type from `TaskStatusName | ''` to `string` to make setTaskFilters compatible with the prop type in ProjectTasks.
  const [taskFilters, setTaskFilters] = useState({ assigneeId: '', status: '' });

  // FIX: Use specific sortable keys type for clientInputSortConfig state to match the prop type in ClientInputsList.
  const [clientInputSortConfig, setClientInputSortConfig] = useState<{ key: SortableClientInputKeys; direction: 'ascending' | 'descending' } | null>({ key: 'requestedOn', direction: 'descending' });
  const [clientInputFilters, setClientInputFilters] = useState({ status: '' });


  const teamMembers = allUsers.filter(u => project.teamMemberIds.includes(u.id));
  const projectLeader = allUsers.find(u => u.id === project.leaderId);

  const requestSort = (key: any, config: any, setConfig: any) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (config && config.key === key && config.direction === 'ascending') {
      direction = 'descending';
    }
    setConfig({ key, direction });
  };
  
  const filteredAndSortedScope = useMemo(() => {
    let items = [...(project.scopeOfWork || [])];
    if (scopeFilters.responsibleParty) {
      items = items.filter(item => item.responsibleParty === scopeFilters.responsibleParty);
    }
    if (scopeSortConfig) {
      items.sort((a, b) => {
        if (a[scopeSortConfig.key] < b[scopeSortConfig.key]) return scopeSortConfig.direction === 'ascending' ? -1 : 1;
        if (a[scopeSortConfig.key] > b[scopeSortConfig.key]) return scopeSortConfig.direction === 'ascending' ? 1 : -1;
        return 0;
      });
    }
    return items;
  }, [project.scopeOfWork, scopeFilters, scopeSortConfig]);

  const filteredAndSortedTasks = useMemo(() => {
    let items = [...project.tasks];
    if (taskFilters.assigneeId) {
      items = items.filter(item => item.assigneeId === taskFilters.assigneeId);
    }
    if (taskFilters.status) {
      items = items.filter(item => item.status === taskFilters.status);
    }
     if (taskSortConfig) {
      items.sort((a, b) => {
        if (a[taskSortConfig.key] < b[taskSortConfig.key]) return taskSortConfig.direction === 'ascending' ? -1 : 1;
        if (a[taskSortConfig.key] > b[taskSortConfig.key]) return taskSortConfig.direction === 'ascending' ? 1 : -1;
        return 0;
      });
    }
    return items;
  }, [project.tasks, taskFilters, taskSortConfig]);

  const filteredAndSortedClientInputs = useMemo(() => {
    let items = [...project.clientInputs];
     if (clientInputFilters.status) {
      items = items.filter(item => item.status === clientInputFilters.status);
    }
    if (clientInputSortConfig) {
      items.sort((a, b) => {
        if (a[clientInputSortConfig.key] < b[clientInputSortConfig.key]) return clientInputSortConfig.direction === 'ascending' ? -1 : 1;
        if (a[clientInputSortConfig.key] > b[clientInputSortConfig.key]) return clientInputSortConfig.direction === 'ascending' ? 1 : -1;
        return 0;
      });
    }
    return items;
  }, [project.clientInputs, clientInputFilters, clientInputSortConfig]);


  return (
    <div className="space-y-6">
      <ProjectHeader project={project} onBack={onBack} teamMembers={teamMembers} />

      <div className="bg-card rounded-2xl border border-border shadow-card">
          <nav className="p-2 flex items-center gap-2 border-b border-border">
              <button onClick={() => setActiveView('scope-of-work')} className={`px-4 py-1.5 text-sm font-semibold rounded-md transition ${activeView === 'scope-of-work' ? 'bg-primary/10 text-primary' : 'text-text-secondary hover:bg-slate-100'}`}>Scope of Work</button>
              <button onClick={() => setActiveView('tasks')} className={`px-4 py-1.5 text-sm font-semibold rounded-md transition ${activeView === 'tasks' ? 'bg-primary/10 text-primary' : 'text-text-secondary hover:bg-slate-100'}`}>Tasks</button>
              <button onClick={() => setActiveView('inputs')} className={`px-4 py-1.5 text-sm font-semibold rounded-md transition ${activeView === 'inputs' ? 'bg-primary/10 text-primary' : 'text-text-secondary hover:bg-slate-100'}`}>Client Inputs</button>
              <button onClick={() => setActiveView('meetings')} className={`px-4 py-1.5 text-sm font-semibold rounded-md transition ${activeView === 'meetings' ? 'bg-primary/10 text-primary' : 'text-text-secondary hover:bg-slate-100'}`}>Meetings</button>
              <button onClick={() => setActiveView('estimations')} className={`px-4 py-1.5 text-sm font-semibold rounded-md transition ${activeView === 'estimations' ? 'bg-primary/10 text-primary' : 'text-text-secondary hover:bg-slate-100'}`}>Estimations</button>
          </nav>
          <div>
            {activeView === 'scope-of-work' && (
                <ScopeOfWorkList 
                    scopeOfWorkItems={filteredAndSortedScope} 
                    users={allUsers}
                    teamMembers={teamMembers}
                    onAdd={onOpenCreateScopeOfWork}
                    onEdit={onOpenEditScopeOfWork}
                    onDelete={onOpenDeleteScopeOfWork}
                    sortConfig={scopeSortConfig}
                    requestSort={(key) => requestSort(key, scopeSortConfig, setScopeSortConfig)}
                    filters={scopeFilters}
                    setFilters={setScopeFilters}
                />
            )}
            {activeView === 'tasks' && (
              <ProjectTasks 
                tasks={filteredAndSortedTasks} 
                users={allUsers}
                teamMembers={teamMembers} 
                onAddTask={onOpenCreateTask} 
                onEditTask={onOpenEditTask} 
                onDeleteTask={onOpenDeleteTask} 
                onViewTask={onViewTask} 
                sortConfig={taskSortConfig}
                requestSort={(key) => requestSort(key, taskSortConfig, setTaskSortConfig)}
                filters={taskFilters}
                setFilters={setTaskFilters}
              />
            )}
              {activeView === 'inputs' && (
              <ClientInputsList 
                clientInputs={filteredAndSortedClientInputs} 
                onAdd={onOpenCreateClientInput} 
                onEdit={onOpenEditClientInput} 
                onDelete={onOpenDeleteClientInput} 
                sortConfig={clientInputSortConfig}
                requestSort={(key) => requestSort(key, clientInputSortConfig, setClientInputSortConfig)}
                filters={clientInputFilters}
                setFilters={setClientInputFilters}
              />
              )}
              {activeView === 'meetings' && (
                <MeetingsList meetings={project.meetings} users={allUsers} onAdd={onOpenCreateMeeting} />
              )}
              {activeView === 'estimations' && (
                <ProjectEstimations 
                  project={project}
                  estimations={project.estimations || []} 
                  onAdd={onOpenCreateEstimation} 
                  onEdit={onOpenEditEstimation} 
                  onDelete={onOpenDeleteEstimation} 
                  onViewHistory={onOpenEstimationHistory}
                />
              )}
          </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <div className="lg:col-span-1">
          <ProjectTeamCard leader={projectLeader} teamMembers={teamMembers} />
        </div>
        <div className="lg:col-span-2">
          <ActivityFeed activities={project.activities} allUsers={allUsers} title="Project Activity" />
        </div>
      </div>
    </div>
  );
};

export default ProjectDashboard;
