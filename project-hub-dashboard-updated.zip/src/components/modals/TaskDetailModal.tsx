import React from 'react';
import type { Task, Project, User, Activity } from '../../types/index.ts';
import { XIcon } from '../icons/XIcon.tsx';
import { CalendarIcon } from '../icons/CalendarIcon.tsx';
import { ClockIcon } from '../icons/ClockIcon.tsx';
import ActivityFeed from '../ActivityFeed.tsx';

interface TaskDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: Task;
  project: Project | null;
  users: User[];
}

const getPriorityClass = (priority: Task['priority']) => {
    switch(priority) {
        case 'High': return 'bg-red-100 text-red-800';
        case 'Medium': return 'bg-amber-100 text-amber-800';
        case 'Low': return 'bg-blue-100 text-blue-800';
        default: return 'bg-slate-100 text-slate-800';
    }
};

const getStatusClass = (status: Task['status']) => {
    switch(status) {
        case 'To Do': return 'bg-slate-100 text-slate-700';
        case 'In Progress': return 'bg-blue-100 text-blue-700';
        case 'Review': return 'bg-amber-100 text-amber-700';
        case 'Done': return 'bg-green-100 text-green-700';
        case 'New': return 'bg-indigo-100 text-indigo-700';
        default: return 'bg-slate-100 text-slate-700';
    }
}

const TaskDetailModal: React.FC<TaskDetailModalProps> = ({ isOpen, onClose, task, project, users }) => {
  if (!isOpen || !project) return null;

  const assignee = users.find(u => u.id === task.assigneeId);
  const creator = users.find(u => u.id === task.creatorId);
  const taskActivities = project.activities.filter(a => a.details.taskTitle === task.title);

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-start justify-end p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-card rounded-2xl shadow-2xl w-full max-w-4xl border border-border transform animate-slide-in flex flex-col h-[calc(100vh-2rem)]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-border flex-shrink-0">
            <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-text-secondary">
                    {project.name}
                </span>
            </div>
            <button
                onClick={onClose}
                className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition"
                aria-label="Close modal"
            >
                <XIcon className="w-6 h-6" />
            </button>
        </div>
        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-3">
           <div className="md:col-span-2 p-6 border-r border-border">
                <div className="flex justify-between items-start">
                    <h2 className="text-2xl font-bold text-text-primary max-w-lg">{task.title}</h2>
                    <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${getStatusClass(task.status)}`}>
                        {task.status}
                    </span>
                </div>
                <div className="mt-4 flex items-center gap-6 text-sm text-text-secondary">
                     <div className="flex items-center gap-2">
                         <CalendarIcon className="w-4 h-4" />
                         <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                     </div>
                     <div className="flex items-center gap-2">
                         <ClockIcon className="w-4 h-4" />
                         <span>Created: {new Date(task.createdOn).toLocaleDateString()}</span>
                     </div>
                 </div>
                 <div className="mt-6 pt-6 border-t border-border">
                    <h3 className="text-lg font-semibold text-text-primary mb-2">Description</h3>
                    <p className="text-text-secondary leading-relaxed">{task.description || 'No description provided.'}</p>
                 </div>
           </div>
           <div className="p-6 bg-slate-50/50">
               <div className="space-y-4">
                    <div>
                        <h3 className="text-sm font-semibold text-text-secondary uppercase mb-2">Assignee</h3>
                         {assignee ? (
                              <div className="flex items-center gap-3">
                                <img src={assignee.avatar} alt={assignee.name} className="w-9 h-9 rounded-full" />
                                <div>
                                    <p className="font-semibold text-text-primary">{assignee.name}</p>
                                    {/* FIX: Replaced `assignee.role` with `assignee.designation` as the 'role' property does not exist on the User type. */}
                                    <p className="text-xs text-text-secondary">{assignee.designation}</p>
                                </div>
                            </div>
                         ) : <p className="text-text-secondary">Unassigned</p>}
                     </div>
                     <div>
                        <h3 className="text-sm font-semibold text-text-secondary uppercase mb-2">Priority</h3>
                         <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${getPriorityClass(task.priority)}`}>
                            {task.priority}
                        </span>
                     </div>
                     <div>
                        <h3 className="text-sm font-semibold text-text-secondary uppercase mb-2">Created By</h3>
                         {creator ? (
                              <div className="flex items-center gap-3">
                                <img src={creator.avatar} alt={creator.name} className="w-8 h-8 rounded-full" />
                                <div>
                                    <p className="font-medium text-sm text-text-primary">{creator.name}</p>
                                </div>
                            </div>
                         ) : <p className="text-text-secondary">Unknown</p>}
                     </div>
               </div>
               <div className="mt-6 pt-6 border-t border-border">
                   <ActivityFeed activities={taskActivities} allUsers={users} title="Task Activity"/>
               </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default TaskDetailModal;