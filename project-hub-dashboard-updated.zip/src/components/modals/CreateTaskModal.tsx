import React, { useState, useEffect } from 'react';
import type { Task, TaskStatusName, TaskPriority, User } from '../../types/index.ts';
import { XIcon } from '../icons/XIcon.tsx';

interface CreateTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: Omit<Task, 'id' | 'createdOn' | 'updatedOn' | 'creatorId' | 'projectId' | 'projectName'>, idToUpdate?: string) => void;
  taskToEdit?: Task | null;
  teamMembers: User[];
  defaultTaskStatus?: TaskStatusName;
}

const CreateTaskModal: React.FC<CreateTaskModalProps> = ({
  isOpen,
  onClose,
  onSave,
  taskToEdit,
  teamMembers,
  defaultTaskStatus = 'To Do',
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assigneeId, setAssigneeId] = useState<string>('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('Normal');
  const [status, setStatus] = useState<TaskStatusName>(defaultTaskStatus);
  const [type, setType] = useState<'Bug' | 'Feature' | 'Task'>('Task');
  const [category, setCategory] = useState('');
  const [error, setError] = useState('');

  const isEditing = !!taskToEdit;

  useEffect(() => {
    if (isOpen) {
      if (isEditing && taskToEdit) {
        setTitle(taskToEdit.title);
        setDescription(taskToEdit.description);
        setAssigneeId(taskToEdit.assigneeId);
        setDueDate(new Date(taskToEdit.dueDate).toISOString().split('T')[0]);
        setPriority(taskToEdit.priority);
        setStatus(taskToEdit.status);
        setType(taskToEdit.type);
        setCategory(taskToEdit.category || '');
      } else {
        // Reset form for creation
        setTitle('');
        setDescription('');
        setAssigneeId(teamMembers[0]?.id || '');
        setDueDate('');
        setPriority('Normal');
        setStatus(defaultTaskStatus);
        setType('Task');
        setCategory('');
      }
      setError('');
    }
  }, [isOpen, isEditing, taskToEdit, teamMembers, defaultTaskStatus]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !assigneeId || !dueDate) {
      setError('Please fill out all required fields.');
      return;
    }
    onSave(
      { title, description, assigneeId, dueDate, priority, status, type, category },
      taskToEdit?.id
    );
  };

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4 animate-fade-in"
        aria-labelledby="modal-title"
        role="dialog"
        aria-modal="true"
      >
        <div
          className="bg-card rounded-2xl shadow-2xl w-full max-w-2xl border border-border transform animate-scale-in"
          role="document"
        >
          <div className="flex items-center justify-between p-6 border-b border-border">
            <h2 id="modal-title" className="text-2xl font-bold text-text-primary">{isEditing ? 'Edit Task' : 'Create New Task'}</h2>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition"
              aria-label="Close modal"
            >
              <XIcon className="w-6 h-6" />
            </button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="p-6 space-y-5 max-h-[60vh] overflow-y-auto">
              <div>
                <label htmlFor="task-title" className="block text-sm font-medium text-text-primary mb-2">Title <span className="text-red-500">*</span></label>
                <input type="text" id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" placeholder="e.g., Design new homepage mockup" />
              </div>
              <div>
                <label htmlFor="task-description" className="block text-sm font-medium text-text-primary mb-2">Description</label>
                <textarea id="task-description" rows={4} value={description} onChange={(e) => setDescription(e.target.value)} className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" placeholder="Add more details about the task..."/>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="assignee" className="block text-sm font-medium text-text-primary mb-2">Assignee <span className="text-red-500">*</span></label>
                    <select id="assignee" value={assigneeId} onChange={(e) => setAssigneeId(e.target.value)} className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                      {teamMembers.map(member => (
                        <option key={member.id} value={member.id}>{member.name}</option>
                      ))}
                    </select>
                  </div>
                   <div>
                    <label htmlFor="due-date" className="block text-sm font-medium text-text-primary mb-2">Due Date <span className="text-red-500">*</span></label>
                    <input type="date" id="due-date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary"/>
                  </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label htmlFor="priority" className="block text-sm font-medium text-text-primary mb-2">Priority</label>
                    <select id="priority" value={priority} onChange={(e) => setPriority(e.target.value as TaskPriority)} className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                        <option>Low</option>
                        <option>Normal</option>
                        <option>Medium</option>
                        <option>High</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="status" className="block text-sm font-medium text-text-primary mb-2">Status</label>
                    <select id="status" value={status} onChange={(e) => setStatus(e.target.value as TaskStatusName)} className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                        <option>New</option>
                        <option>To Do</option>
                        <option>In Progress</option>
                        <option>Review</option>
                        <option>Done</option>
                    </select>
                </div>
              </div>
              {error && <p className="text-sm text-red-500 text-center">{error}</p>}
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-border flex justify-end gap-3 rounded-b-2xl">
              <button type="button" onClick={onClose} className="px-5 py-2.5 text-sm font-medium rounded-lg bg-card text-text-primary border border-border hover:bg-slate-100 transition">Cancel</button>
              <button type="submit" className="px-5 py-2.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-indigo-700 transition">{isEditing ? 'Save Changes' : 'Create Task'}</button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default CreateTaskModal;