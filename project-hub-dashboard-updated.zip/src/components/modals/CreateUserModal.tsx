import React, { useState, useEffect } from 'react';
import type { User } from '../../types/index.ts';
import { XIcon } from '../icons/XIcon.tsx';

interface CreateUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateUser: (user: Omit<User, 'id' | 'avatar' | 'projects'> & { projects: string }) => void;
}

const CreateUserModal: React.FC<CreateUserModalProps> = ({ isOpen, onClose, onCreateUser }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [designation, setDesignation] = useState('');
  const [department, setDepartment] = useState('');
  const [projects, setProjects] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) {
      // Reset form
      setName('');
      setEmail('');
      setDesignation('');
      setDepartment('');
      setProjects('');
      setError('');
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !designation.trim() || !department.trim()) {
      setError('Please fill out all fields.');
      return;
    }
    // FIX: Removed the `avatar` property from the object passed to `onCreateUser`. The server will generate it, and the prop type doesn't allow it.
    onCreateUser({ name, email, designation, department, projects });
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4 animate-fade-in"
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
    >
      <div
        className="bg-card rounded-2xl shadow-2xl w-full max-w-lg border border-border transform animate-scale-in"
        role="document"
      >
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 id="modal-title" className="text-2xl font-bold text-text-primary">Create New User</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition"
            aria-label="Close modal"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-5">
            <div>
              <label htmlFor="user-name" className="block text-sm font-medium text-text-primary mb-2">Full Name</label>
              <input
                type="text"
                id="user-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"
                placeholder="e.g., Jane Doe"
              />
            </div>
            <div>
              <label htmlFor="user-email" className="block text-sm font-medium text-text-primary mb-2">Email Address</label>
              <input
                type="email"
                id="user-email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"
                placeholder="e.g., jane.doe@example.com"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="user-designation" className="block text-sm font-medium text-text-primary mb-2">Designation</label>
                <input
                  type="text"
                  id="user-designation"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"
                  placeholder="e.g., Software Developer"
                />
              </div>
              <div>
                <label htmlFor="user-department" className="block text-sm font-medium text-text-primary mb-2">Department</label>
                <input
                  type="text"
                  id="user-department"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"
                  placeholder="e.g., IT"
                />
              </div>
            </div>
            <div>
              <label htmlFor="user-projects" className="block text-sm font-medium text-text-primary mb-2">Project(s)</label>
              <input
                type="text"
                id="user-projects"
                value={projects}
                onChange={(e) => setProjects(e.target.value)}
                className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"
                placeholder="e.g., Titan BCM, CETS (comma-separated)"
              />
            </div>
            {error && <p className="text-sm text-red-500 text-center">{error}</p>}
          </div>
          <div className="px-6 py-4 bg-slate-50 border-t border-border flex justify-end gap-3 rounded-b-2xl">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-sm font-medium rounded-lg bg-card text-text-primary border border-border hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-indigo-700 transition"
            >
              Create User
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateUserModal;