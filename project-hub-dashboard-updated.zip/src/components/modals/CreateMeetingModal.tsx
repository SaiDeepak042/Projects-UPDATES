import React, { useState, useEffect } from 'react';
import type { Meeting, User } from '../../types/index.ts';
import { XIcon } from '../icons/XIcon.tsx';

interface CreateMeetingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (meeting: Omit<Meeting, 'id'>) => void;
  teamMembers: User[];
}

const CreateMeetingModal: React.FC<CreateMeetingModalProps> = ({ isOpen, onClose, onCreate, teamMembers }) => {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [attendees, setAttendees] = useState<string[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) {
      setTitle('');
      setDate('');
      setTime('');
      setAttendees([]);
      setError('');
    } else {
        setDate(new Date().toISOString().split('T')[0]); // Default to today
    }
  }, [isOpen]);

  const handleAttendeeToggle = (id: string) => {
    setAttendees(prev => prev.includes(id) ? prev.filter(attId => attId !== id) : [...prev, id]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !date || !time || attendees.length === 0) {
      setError('Please fill out all fields and select at least one attendee.');
      return;
    }
    onCreate({
      title,
      date,
      time,
      attendees,
    });
  };
  
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4 animate-fade-in"
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-card rounded-2xl shadow-2xl w-full max-w-lg border border-border transform animate-scale-in"
        role="document"
      >
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 id="modal-title" className="text-2xl font-bold text-text-primary">Schedule Meeting</h2>
          <button 
            onClick={onClose} 
            className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition"
            aria-label="Close modal"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-5">
            <div>
              <label htmlFor="meeting-title" className="block text-sm font-medium text-text-primary mb-2">Meeting Title</label>
              <input
                type="text"
                id="meeting-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"
                placeholder="e.g., Weekly Sync"
              />
            </div>
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label htmlFor="date" className="block text-sm font-medium text-text-primary mb-2">Date</label>
                    <input type="date" id="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary"/>
                </div>
                 <div>
                    <label htmlFor="time" className="block text-sm font-medium text-text-primary mb-2">Time</label>
                    <input type="time" id="time" value={time} onChange={(e) => setTime(e.target.value)} className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary"/>
                </div>
            </div>
             <div>
                <label className="block text-sm font-medium text-text-primary mb-2">Attendees</label>
                <div className="flex flex-wrap gap-2 p-3 bg-background border border-border rounded-lg">
                    {teamMembers.map(member => (
                        <button type="button" key={member.id} onClick={() => handleAttendeeToggle(member.id)} className={`flex items-center gap-2 p-2 rounded-md text-sm transition ${attendees.includes(member.id) ? 'bg-primary text-white' : 'bg-border text-text-primary'}`}>
                            <img src={member.avatar} alt={member.name} className="w-6 h-6 rounded-full" />
                            <span>{member.name}</span>
                        </button>
                    ))}
                </div>
             </div>
             {error && <p className="text-sm text-red-500 text-center">{error}</p>}
          </div>
          <div className="px-6 py-4 bg-slate-50 border-t border-border flex justify-end gap-3 rounded-b-2xl">
            <button type="button" onClick={onClose} className="px-5 py-2.5 text-sm font-medium rounded-lg bg-card text-text-primary border border-border hover:bg-slate-100 transition">Cancel</button>
            <button type="submit" className="px-5 py-2.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-indigo-700 transition">Schedule</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateMeetingModal;