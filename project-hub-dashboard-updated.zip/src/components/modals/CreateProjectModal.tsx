import React, { useState, useEffect } from 'react';
import type { Project, User } from '../../types/index.ts';
import {
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogCloseButton,
} from '../ui/dialog.tsx';
import { Button } from '../ui/button.tsx';
import { Input } from '../ui/input.tsx';
import { Label } from '../ui/label.tsx';


interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateProject: (project: Omit<Project, 'id' | 'status' | 'progress'>) => void;
  currentUser: User;
}

const CreateProjectModal: React.FC<CreateProjectModalProps> = ({ isOpen, onClose, onCreateProject, currentUser }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [team, setTeam] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) {
      // Reset form when modal is closed
      setName('');
      setDescription('');
      setTeam('');
      setDueDate('');
      setError('');
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !description.trim() || !team.trim() || !dueDate) {
      setError('Please fill out all fields.');
      return;
    }
    // Fix: Added missing 'scopeOfWork' property to the new project object to satisfy the 'Project' type.
    onCreateProject({
      name,
      description,
      leaderId: currentUser.id,
      teamMemberIds: team.split(',').map(t => t.trim()),
      dueDate,
      tasks: [],
      activities: [],
      clientInputs: [],
      meetings: [],
      estimations: [],
      scopeOfWork: [],
    });
    onClose();
  };
  
  // Fix: Replaced Dialog wrapper with a div and an isOpen check to align with other modal components and fix a TypeScript error.
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4 animate-fade-in"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
        <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Project</DialogTitle>
              <DialogCloseButton onClose={onClose} />
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="p-6 space-y-5">
                <div>
                  <Label htmlFor="project-name">Project Name</Label>
                  <Input
                    type="text"
                    id="project-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g., Q4 Marketing Campaign"
                  />
                </div>
                <div>
                  <Label htmlFor="project-description">Description</Label>
                  <textarea
                    id="project-description"
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"
                    placeholder="A brief summary of the project goals..."
                  />
                </div>
                <div>
                  <Label htmlFor="team-members">Team Members</Label>
                  <Input
                    type="text"
                    id="team-members"
                    value={team}
                    onChange={(e) => setTeam(e.target.value)}
                    placeholder="Add team member initials, comma separated (e.g., A, B, C)"
                  />
                </div>
                <div>
                  <Label htmlFor="due-date">Due Date</Label>
                  <Input
                    type="date"
                    id="due-date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                  />
                </div>
                 {error && <p className="text-sm text-red-500 text-center">{error}</p>}
              </div>
              <DialogFooter>
                <Button 
                  type="button"
                  variant="outline"
                  onClick={onClose} 
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                >
                  Create Project
                </Button>
              </DialogFooter>
            </form>
        </DialogContent>
    </div>
  );
};

export default CreateProjectModal;