import React, { useState, useEffect, useRef } from 'react';
import type { ClientInput, ClientInputStatus } from '../../types/index.ts';
import { XIcon } from '../icons/XIcon.tsx';

interface CreateClientInputModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (input: Omit<ClientInput, 'id' | 'files'> & { files?: File[] }, idToUpdate?: string) => void;
  inputToEdit?: ClientInput | null;
}

const CreateClientInputModal: React.FC<CreateClientInputModalProps> = ({ isOpen, onClose, onSave, inputToEdit }) => {
  const [description, setDescription] = useState('');
  const [requestedOn, setRequestedOn] = useState('');
  const [requestedBy, setRequestedBy] = useState('');
  const [receivedOn, setReceivedOn] = useState('');
  const [hasReceived, setHasReceived] = useState(false);
  const [assignee, setAssignee] = useState('');
  const [status, setStatus] = useState<ClientInputStatus>('Pending');
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState('');
  const isEditing = !!inputToEdit;

  useEffect(() => {
    if (isOpen) {
        if (isEditing && inputToEdit) {
            setDescription(inputToEdit.description);
            setRequestedOn(inputToEdit.requestedOn.split('T')[0]);
            setRequestedBy(inputToEdit.requestedBy);
            setReceivedOn(inputToEdit.receivedOn ? inputToEdit.receivedOn.split('T')[0] : '');
            setHasReceived(inputToEdit.hasReceived);
            setAssignee(inputToEdit.assignee || '');
            setStatus(inputToEdit.status);
            setFiles([]); // Don't allow re-editing of files for simplicity
        } else {
            // Reset for creation
            setDescription('');
            setRequestedOn(new Date().toISOString().split('T')[0]);
            setRequestedBy('');
            setReceivedOn('');
            setHasReceived(false);
            setAssignee('');
            setStatus('Pending');
            setFiles([]);
        }
        setError('');
    }
  }, [isOpen, isEditing, inputToEdit]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || !requestedOn || !requestedBy) {
      setError('Please fill out all required fields.');
      return;
    }
    
    const inputData = {
      description,
      requestedOn,
      requestedBy,
      receivedOn: hasReceived ? receivedOn : undefined,
      hasReceived,
      assignee: assignee || undefined,
      status,
      files,
    };
    
    onSave(inputData, inputToEdit?.id);
  };
  
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4 animate-fade-in"
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-card rounded-2xl shadow-2xl w-full max-w-2xl border border-border transform animate-scale-in"
        role="document"
      >
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 id="modal-title" className="text-2xl font-bold text-text-primary">
            {isEditing ? 'Edit Input Request' : 'New Input Request'}
          </h2>
          <button 
            onClick={onClose} 
            className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition"
            aria-label="Close modal"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] items-center gap-4">
              <label htmlFor="description" className="text-sm font-medium text-text-primary">Input Description <span className="text-red-500">*</span></label>
              <input type="text" id="description" value={description} onChange={e => setDescription(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"/>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] items-center gap-4">
              <label htmlFor="requested-on" className="text-sm font-medium text-text-primary">Requested On <span className="text-red-500">*</span></label>
              <input type="date" id="requested-on" value={requestedOn} onChange={e => setRequestedOn(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"/>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] items-center gap-4">
              <label htmlFor="requested-by" className="text-sm font-medium text-text-primary">Requested By <span className="text-red-500">*</span></label>
              <input type="text" id="requested-by" value={requestedBy} onChange={e => setRequestedBy(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"/>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] items-center gap-4">
              <label htmlFor="received-on" className="text-sm font-medium text-text-primary">Received On</label>
              <div className="flex items-center gap-4">
                <input type="date" id="received-on" value={receivedOn} onChange={e => setReceivedOn(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"/>
                <div className="flex items-center">
                  <input id="has-received" type="checkbox" checked={hasReceived} onChange={e => setHasReceived(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary" />
                  <label htmlFor="has-received" className="ml-2 block text-sm text-text-primary">Has Received</label>
                </div>
              </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] items-center gap-4">
              <label htmlFor="assignee" className="text-sm font-medium text-text-primary">Assignee</label>
              <input type="text" id="assignee" value={assignee} onChange={e => setAssignee(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"/>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] items-center gap-4">
              <label htmlFor="status" className="text-sm font-medium text-text-primary">Status <span className="text-red-500">*</span></label>
              <select id="status" value={status} onChange={e => setStatus(e.target.value as ClientInputStatus)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                <option>Pending</option>
                <option>Completed</option>
                <option>On Hold</option>
              </select>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] items-start gap-4">
              <label className="text-sm font-medium text-text-primary pt-2">Upload Files</label>
              <div className="flex items-center gap-4">
                <input type="file" id="file-upload" multiple onChange={handleFileChange} className="hidden" />
                <label htmlFor="file-upload" className="cursor-pointer px-4 py-2 text-sm font-medium rounded-lg bg-card text-text-primary border border-border hover:bg-slate-100 transition">Select Files...</label>
                <div className="flex-1 p-2 border border-border bg-background rounded-lg min-h-[40px] text-sm text-text-secondary">
                    {files.length > 0 ? files.map(f => f.name).join(', ') : (isEditing ? 'Select new files to overwrite' : 'No files selected')}
                </div>
              </div>
            </div>
            {error && <p className="text-sm text-red-500 text-center pt-2">{error}</p>}
          </div>
          <div className="px-6 py-4 bg-slate-50 border-t border-border flex justify-end items-center gap-3 rounded-b-2xl">
            <button type="submit" className="px-5 py-2.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-indigo-700 transition">
              {isEditing ? 'Save Changes' : 'Save'}
            </button>
            <button type="button" disabled className="px-5 py-2.5 text-sm font-medium rounded-lg bg-card text-text-primary/50 border border-border cursor-not-allowed" title="Feature not available">Upload to OneDrive</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateClientInputModal;