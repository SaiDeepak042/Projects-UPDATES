import React from 'react';
import type { Estimation, Activity, User } from '../../types/index.ts';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogCloseButton,
} from '../ui/dialog.tsx';
import ActivityFeed from '../ActivityFeed.tsx';

interface EstimationHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  estimation: Estimation | null;
  projectActivities: Activity[];
  allUsers: User[];
}

const EstimationHistoryModal: React.FC<EstimationHistoryModalProps> = ({ isOpen, onClose, estimation, projectActivities, allUsers }) => {
  if (!isOpen || !estimation) return null;

  const estimationActivities = projectActivities.filter(
    (activity) => activity.details.estimationId === estimation.id
  ).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <Dialog isOpen={isOpen} onClose={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>History for "{estimation.featureTask} - {estimation.subtask}"</DialogTitle>
          <DialogCloseButton onClose={onClose} />
        </DialogHeader>
        <div className="p-6 max-h-[60vh] overflow-y-auto">
          <ActivityFeed activities={estimationActivities} allUsers={allUsers} title="Estimation History" />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EstimationHistoryModal;
