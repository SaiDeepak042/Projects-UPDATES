import React from 'react';
import { XIcon } from '../icons/XIcon.tsx';
import { TrashIcon } from '../icons/TrashIcon.tsx';

interface ConfirmDeleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  itemName: string;
  itemType?: string;
}

const ConfirmDeleteModal: React.FC<ConfirmDeleteModalProps> = ({ isOpen, onClose, onConfirm, itemName, itemType = 'item' }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 animate-fade-in"
      aria-labelledby="delete-modal-title"
      role="dialog"
      aria-modal="true"
    >
      <div
        className="bg-card rounded-2xl shadow-2xl w-full max-w-md border border-border transform animate-scale-in"
        role="document"
      >
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 id="delete-modal-title" className="text-xl font-bold text-text-primary">Confirm Deletion</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition"
            aria-label="Close modal"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6">
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
              <TrashIcon className="h-6 w-6 text-red-600" />
            </div>
            <h3 className="mt-5 text-lg font-medium leading-6 text-text-primary">
              Are you sure?
            </h3>
            <div className="mt-2 text-sm text-text-secondary">
              <p>
                You are about to permanently delete the {itemType} <strong className="text-text-primary">"{itemName}"</strong>. This action cannot be undone.
              </p>
            </div>
          </div>
        </div>
        <div className="px-6 py-4 bg-slate-50 border-t border-border flex justify-end gap-3 rounded-b-2xl">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 text-sm font-medium rounded-lg bg-card text-text-primary border border-border hover:bg-slate-100 transition"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-5 py-2.5 text-sm font-medium rounded-lg bg-red-600 text-white hover:bg-red-700 transition"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmDeleteModal;