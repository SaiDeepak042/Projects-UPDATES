import React, { useState, useEffect } from 'react';
import type { ScopeOfWork, User, EstimationPriority, EstimationRisk } from '../../types/index.ts';
import { XIcon } from '../icons/XIcon.tsx';

interface CreateScopeOfWorkModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (scope: Omit<ScopeOfWork, 'id' | 'projectId'>, idToUpdate?: string) => void;
  scopeToEdit?: ScopeOfWork | null;
  teamMembers: User[];
}

const CreateScopeOfWorkModal: React.FC<CreateScopeOfWorkModalProps> = ({ isOpen, onClose, onSave, scopeToEdit, teamMembers }) => {
    const [scopeOfWork, setScopeOfWork] = useState('');
    const [featureModule, setFeatureModule] = useState('');
    const [taskSubtask, setTaskSubtask] = useState('');
    const [description, setDescription] = useState('');
    const [deliverables, setDeliverables] = useState('');
    const [acceptanceCriteria, setAcceptanceCriteria] = useState('');
    const [estimatedEffort, setEstimatedEffort] = useState<number | string>(0);
    const [dependencies, setDependencies] = useState('');
    const [responsibleParty, setResponsibleParty] = useState('');
    const [priority, setPriority] = useState<EstimationPriority>('Low');
    const [riskLevel, setRiskLevel] = useState<EstimationRisk>('Low');
    const [notes, setNotes] = useState('');
    const [error, setError] = useState('');

    const isEditing = !!scopeToEdit;

    useEffect(() => {
        if (isOpen) {
            if (isEditing && scopeToEdit) {
                setScopeOfWork(scopeToEdit.scopeOfWork);
                setFeatureModule(scopeToEdit.featureModule);
                setTaskSubtask(scopeToEdit.taskSubtask);
                setDescription(scopeToEdit.description);
                setDeliverables(scopeToEdit.deliverables);
                setAcceptanceCriteria(scopeToEdit.acceptanceCriteria);
                setEstimatedEffort(scopeToEdit.estimatedEffort);
                setDependencies(scopeToEdit.dependencies);
                setResponsibleParty(scopeToEdit.responsibleParty);
                setPriority(scopeToEdit.priority);
                setRiskLevel(scopeToEdit.riskLevel);
                setNotes(scopeToEdit.notes);
            } else {
                setScopeOfWork('');
                setFeatureModule('');
                setTaskSubtask('');
                setDescription('');
                setDeliverables('');
                setAcceptanceCriteria('');
                setEstimatedEffort(0);
                setDependencies('');
                setResponsibleParty(teamMembers[0]?.id || '');
                setPriority('Medium');
                setRiskLevel('Low');
                setNotes('');
            }
            setError('');
        }
    }, [isOpen, isEditing, scopeToEdit, teamMembers]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!featureModule.trim() || !taskSubtask.trim() || !responsibleParty) {
            setError('Please fill out Feature/Module, Task/Subtask, and Responsible Party.');
            return;
        }
        onSave(
            { scopeOfWork, featureModule, taskSubtask, description, deliverables, acceptanceCriteria, estimatedEffort: +estimatedEffort, dependencies, responsibleParty, priority, riskLevel, notes },
            scopeToEdit?.id
        );
    };

    if (!isOpen) return null;

    return (
        <div
            className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4 animate-fade-in"
            aria-labelledby="modal-title"
            role="dialog"
            aria-modal="true"
        >
            <div
                className="bg-card rounded-2xl shadow-2xl w-full max-w-4xl border border-border transform animate-scale-in"
                role="document"
            >
                <div className="flex items-center justify-between p-6 border-b border-border">
                    <h2 id="modal-title" className="text-2xl font-bold text-text-primary">{isEditing ? 'Edit Scope of Work Item' : 'Create Scope of Work Item'}</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition" aria-label="Close modal">
                        <XIcon className="w-6 h-6" />
                    </button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4 max-h-[70vh] overflow-y-auto">
                        {/* Row 1 */}
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Scope of Work</label>
                            <input type="text" value={scopeOfWork} onChange={(e) => setScopeOfWork(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Feature / Module</label>
                            <input type="text" value={featureModule} onChange={(e) => setFeatureModule(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Task / Subtask</label>
                            <input type="text" value={taskSubtask} onChange={(e) => setTaskSubtask(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>
                        
                        {/* Row 2 */}
                        <div className="md:col-span-3">
                            <label className="block text-sm font-medium text-text-primary mb-2">Description</label>
                            <textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>
                        
                        {/* Row 3 */}
                        <div className="md:col-span-3">
                             <label className="block text-sm font-medium text-text-primary mb-2">Deliverables</label>
                             <textarea rows={3} value={deliverables} onChange={(e) => setDeliverables(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>

                        {/* Row 4 */}
                        <div className="md:col-span-3">
                            <label className="block text-sm font-medium text-text-primary mb-2">Acceptance Criteria</label>
                            <textarea rows={3} value={acceptanceCriteria} onChange={(e) => setAcceptanceCriteria(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>

                         {/* Row 5 */}
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Estimated Effort (hrs)</label>
                            <input type="number" value={estimatedEffort} onChange={(e) => setEstimatedEffort(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Dependencies</label>
                            <input type="text" value={dependencies} onChange={(e) => setDependencies(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Responsible Party</label>
                            <select value={responsibleParty} onChange={(e) => setResponsibleParty(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                              {teamMembers.map(member => (
                                <option key={member.id} value={member.id}>{member.name}</option>
                              ))}
                            </select>
                        </div>

                        {/* Row 6 */}
                        <div>
                            <label className="block text-sm font-medium text-text-primary mb-2">Priority</label>
                            <select value={priority} onChange={(e) => setPriority(e.target.value as EstimationPriority)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                                <option>Low</option>
                                <option>Medium</option>
                                <option>High</option>
                            </select>
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-text-primary mb-2">Risk Level</label>
                            <select value={riskLevel} onChange={(e) => setRiskLevel(e.target.value as EstimationRisk)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                                <option>Low</option>
                                <option>Medium</option>
                                <option>High</option>
                            </select>
                        </div>
                        
                        {/* Row 7 */}
                        <div className="md:col-span-3">
                            <label className="block text-sm font-medium text-text-primary mb-2">Notes</label>
                             <textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary" />
                        </div>

                        {error && <p className="text-sm text-red-500 text-center md:col-span-3">{error}</p>}
                    </div>
                    <div className="px-6 py-4 bg-slate-50 border-t border-border flex justify-end gap-3 rounded-b-2xl">
                        <button type="button" onClick={onClose} className="px-5 py-2.5 text-sm font-medium rounded-lg bg-card text-text-primary border border-border hover:bg-slate-100 transition">Cancel</button>
                        <button type="submit" className="px-5 py-2.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-primary-hover transition">{isEditing ? 'Save Changes' : 'Save Item'}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreateScopeOfWorkModal;