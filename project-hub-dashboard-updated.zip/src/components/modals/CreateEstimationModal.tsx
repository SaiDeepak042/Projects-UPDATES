import React, { useState, useEffect } from 'react';
import type { Estimation, EstimationProjectType, EstimationComplexity, EstimationRisk, EstimationPriority } from '../../types/index.ts';
import { XIcon } from '../icons/XIcon.tsx';

interface CreateEstimationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (estimation: Omit<Estimation, 'id' | 'createdOn' | 'updatedOn' | 'creatorId' | 'projectId'>, idToUpdate?: string) => void;
  estimationToEdit?: Estimation | null;
}

const CreateEstimationModal: React.FC<CreateEstimationModalProps> = ({ isOpen, onClose, onSave, estimationToEdit }) => {
    const [phase, setPhase] = useState('');
    const [featureTask, setFeatureTask] = useState('');
    const [subtask, setSubtask] = useState('');
    const [projectType, setProjectType] = useState<EstimationProjectType>('Web');
    const [technologyStack, setTechnologyStack] = useState('');
    const [complexity, setComplexity] = useState<EstimationComplexity>('Low');
    const [estimatedHours, setEstimatedHours] = useState<number | string>(0);
    const [dependencies, setDependencies] = useState('');
    const [developerNotes, setDeveloperNotes] = useState('');
    const [riskLevel, setRiskLevel] = useState<EstimationRisk>('Low');
    const [priority, setPriority] = useState<EstimationPriority>('Low');
    const [error, setError] = useState('');

    const isEditing = !!estimationToEdit;

    useEffect(() => {
        if (isOpen) {
            if (isEditing && estimationToEdit) {
                setPhase(estimationToEdit.phase);
                setFeatureTask(estimationToEdit.featureTask);
                setSubtask(estimationToEdit.subtask);
                setProjectType(estimationToEdit.projectType);
                setTechnologyStack(estimationToEdit.technologyStack);
                setComplexity(estimationToEdit.complexity);
                setEstimatedHours(estimationToEdit.estimatedHours);
                setDependencies(estimationToEdit.dependencies);
                setDeveloperNotes(estimationToEdit.developerNotes);
                setRiskLevel(estimationToEdit.riskLevel);
                setPriority(estimationToEdit.priority);
            } else {
                setPhase('');
                setFeatureTask('');
                setSubtask('');
                setProjectType('Web');
                setTechnologyStack('');
                setComplexity('Low');
                setEstimatedHours(0);
                setDependencies('');
                setDeveloperNotes('');
                setRiskLevel('Low');
                setPriority('Low');
            }
            setError('');
        }
    }, [isOpen, isEditing, estimationToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!featureTask.trim() || estimatedHours === '' || +estimatedHours < 0) {
            setError('Please fill out all required fields with valid values.');
            return;
        }
        onSave(
            { phase, featureTask, subtask, projectType, technologyStack, complexity, estimatedHours: +estimatedHours, dependencies, developerNotes, riskLevel, priority },
            estimationToEdit?.id
        );
    };

    if (!isOpen) return null;

    return (
        <div
            className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4 animate-fade-in"
            aria-labelledby="modal-title"
            role="dialog"
            aria-modal="true"
        >
            <div
                className="bg-card rounded-2xl shadow-2xl w-full max-w-3xl border border-border transform animate-scale-in"
                role="document"
            >
                <div className="flex items-center justify-between p-6 border-b border-border">
                    <h2 id="modal-title" className="text-2xl font-bold text-text-primary">{isEditing ? 'Edit Estimation' : 'Create Estimation'}</h2>
                    <button
                    onClick={onClose}
                    className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition"
                    aria-label="Close modal"
                    >
                    <XIcon className="w-6 h-6" />
                    </button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 max-h-[70vh] overflow-y-auto">
                        <div className="md:col-span-2">
                            <label htmlFor="phase" className="block text-sm font-medium text-text-primary mb-2">Phase</label>
                            <input type="text" id="phase" value={phase} onChange={(e) => setPhase(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="feature-task" className="block text-sm font-medium text-text-primary mb-2">Feature / Task <span className="text-red-500">*</span></label>
                            <input type="text" id="feature-task" value={featureTask} onChange={(e) => setFeatureTask(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="subtask" className="block text-sm font-medium text-text-primary mb-2">Subtask</label>
                            <input type="text" id="subtask" value={subtask} onChange={(e) => setSubtask(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="project-type" className="block text-sm font-medium text-text-primary mb-2">Project Type</label>
                            <select id="project-type" value={projectType} onChange={(e) => setProjectType(e.target.value as EstimationProjectType)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                                <option>Web</option>
                                <option>CAD</option>
                                <option>Both</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="tech-stack" className="block text-sm font-medium text-text-primary mb-2">Technology Stack</label>
                            <input type="text" id="tech-stack" value={technologyStack} onChange={(e) => setTechnologyStack(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" />
                        </div>
                         <div>
                            <label htmlFor="complexity" className="block text-sm font-medium text-text-primary mb-2">Complexity</label>
                            <select id="complexity" value={complexity} onChange={(e) => setComplexity(e.target.value as EstimationComplexity)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                                <option>Low</option>
                                <option>Medium</option>
                                <option>High</option>
                            </select>
                        </div>
                         <div>
                            <label htmlFor="est-hours" className="block text-sm font-medium text-text-primary mb-2">Estimated Hours <span className="text-red-500">*</span></label>
                            <input type="number" id="est-hours" value={estimatedHours} onChange={(e) => setEstimatedHours(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="dependencies" className="block text-sm font-medium text-text-primary mb-2">Dependencies</label>
                            <input type="text" id="dependencies" value={dependencies} onChange={(e) => setDependencies(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="dev-notes" className="block text-sm font-medium text-text-primary mb-2">Developer Notes</label>
                            <textarea id="dev-notes" rows={1} value={developerNotes} onChange={(e) => setDeveloperNotes(e.target.value)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="risk-level" className="block text-sm font-medium text-text-primary mb-2">Risk Level</label>
                            <select id="risk-level" value={riskLevel} onChange={(e) => setRiskLevel(e.target.value as EstimationRisk)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                                <option>Low</option>
                                <option>Medium</option>
                                <option>High</option>
                            </select>
                        </div>
                         <div>
                            <label htmlFor="priority" className="block text-sm font-medium text-text-primary mb-2">Priority</label>
                            <select id="priority" value={priority} onChange={(e) => setPriority(e.target.value as EstimationPriority)} className="w-full px-4 py-2 bg-background border border-border rounded-lg text-text-primary focus:ring-2 focus:ring-primary focus:outline-none transition">
                                <option>Low</option>
                                <option>Medium</option>
                                <option>High</option>
                            </select>
                        </div>
                        {error && <p className="text-sm text-red-500 text-center md:col-span-2">{error}</p>}
                    </div>
                    <div className="px-6 py-4 bg-slate-50 border-t border-border flex justify-end gap-3 rounded-b-2xl">
                        <button type="button" onClick={onClose} className="px-5 py-2.5 text-sm font-medium rounded-lg bg-card text-text-primary border border-border hover:bg-slate-100 transition">Cancel</button>
                        <button type="submit" className="px-5 py-2.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-primary-hover transition">{isEditing ? 'Save Changes' : 'Save Estimation'}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreateEstimationModal;