import React, { useState, useMemo } from 'react';
import type { Estimation, Project, EstimationComplexity, EstimationRisk } from '../types/index.ts';
import { PlusIcon } from './icons/PlusIcon.tsx';
import { PencilIcon } from './icons/PencilIcon.tsx';
import { TrashIcon } from './icons/TrashIcon.tsx';
import { HistoryIcon } from './icons/HistoryIcon.tsx';
import { SortIcon } from './icons/SortIcon.tsx';
import { ArrowUpIcon } from './icons/ArrowUpIcon.tsx';
import { ArrowDownIcon } from './icons/ArrowDownIcon.tsx';

interface ProjectEstimationsProps {
  project: Project;
  estimations: Estimation[];
  onAdd: () => void;
  onEdit: (estimation: Estimation) => void;
  onDelete: (estimation: Estimation) => void;
  onViewHistory: (estimation: Estimation) => void;
}

// FIX: Added 'featureTask' to SortableKeys to allow sorting by this column and fix the type error in useState.
type SortableKeys = 'featureTask' | 'estimatedHours' | 'complexity' | 'riskLevel';
type SortConfig = { key: SortableKeys; direction: 'ascending' | 'descending' } | null;


const ProjectEstimations: React.FC<ProjectEstimationsProps> = ({ project, estimations, onAdd, onEdit, onDelete, onViewHistory }) => {
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'featureTask', direction: 'ascending'});
  
  const totalHours = estimations.reduce((sum, item) => sum + item.estimatedHours, 0);

  const estimationsByPhase = useMemo(() => {
    // Grouping
    const grouped = estimations.reduce((acc, est) => {
        const phase = est.phase || 'Unphased';
        if (!acc[phase]) acc[phase] = [];
        acc[phase].push(est);
        return acc;
    }, {} as Record<string, Estimation[]>);

    // Sorting within groups
    if (sortConfig) {
      for (const phase in grouped) {
        grouped[phase].sort((a, b) => {
          const aValue = a[sortConfig.key];
          const bValue = b[sortConfig.key];

          if (sortConfig.key === 'complexity' || sortConfig.key === 'riskLevel') {
              const order: Record<EstimationComplexity | EstimationRisk, number> = { 'Low': 1, 'Medium': 2, 'High': 3 };
              const aOrder = order[aValue as EstimationComplexity | EstimationRisk];
              const bOrder = order[bValue as EstimationComplexity | EstimationRisk];
               if (aOrder < bOrder) return sortConfig.direction === 'ascending' ? -1 : 1;
               if (aOrder > bOrder) return sortConfig.direction === 'ascending' ? 1 : -1;
               return 0;
          }

          if (aValue < bValue) return sortConfig.direction === 'ascending' ? -1 : 1;
          if (aValue > bValue) return sortConfig.direction === 'ascending' ? 1 : -1;
          return 0;
        });
      }
    }
    return grouped;
  }, [estimations, sortConfig]);

  const requestSort = (key: SortableKeys) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIcon = (key: SortableKeys) => {
    if (!sortConfig || sortConfig.key !== key) return <SortIcon className="w-4 h-4" />;
    return sortConfig.direction === 'ascending' ? <ArrowUpIcon className="w-4 h-4" /> : <ArrowDownIcon className="w-4 h-4" />;
  }


  return (
    <div className="bg-card rounded-b-2xl h-full flex flex-col">
      <div className="p-4 flex justify-between items-center">
        <div>
            <h2 className="text-xl font-bold text-text-primary">Project Estimations</h2>
            <p className="text-sm text-text-secondary">Managing estimations for: {project.name}</p>
        </div>
        <div className="flex items-center gap-4">
            <div className="text-right">
                <p className="text-sm text-text-secondary">Total Estimated Hours</p>
                <p className="text-3xl font-bold text-primary">{totalHours}</p>
            </div>
            <button
            onClick={onAdd}
            className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-primary rounded-lg hover:bg-primary-hover transition-colors"
            >
            <PlusIcon className="w-5 h-5" />
            Add Task
            </button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {estimations.length > 0 ? (
          <div className="border-t border-border">
            {Object.entries(estimationsByPhase).map(([phase, phaseEstimations]) => {
              const phaseTotal = phaseEstimations.reduce((sum, item) => sum + item.estimatedHours, 0);
              return (
                <div key={phase}>
                  <div className="p-3 px-4 bg-card flex justify-between items-center sticky top-0 z-10">
                    <h3 className="font-bold text-base text-text-primary">{phase}</h3>
                    <p className="text-sm font-medium text-text-secondary">Phase Total: <span className="font-bold text-text-primary">{phaseTotal} Hours</span></p>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead>
                        <tr className="border-b border-t border-border">
                            {/* FIX: Added cursor-pointer and onClick handler to make the Feature/Task column sortable. */}
                            <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider w-2/5 cursor-pointer" onClick={() => requestSort('featureTask')}>
                                <div className="flex items-center gap-1">Feature / Task {getSortIcon('featureTask')}</div>
                            </th>
                            <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('estimatedHours')}>
                                <div className="flex items-center gap-1">Hours {getSortIcon('estimatedHours')}</div>
                            </th>
                            <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('complexity')}>
                                <div className="flex items-center gap-1">Complexity {getSortIcon('complexity')}</div>
                            </th>
                            <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('riskLevel')}>
                                <div className="flex items-center gap-1">Risk {getSortIcon('riskLevel')}</div>
                            </th>
                            <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider text-center">History</th>
                            <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider text-center">Actions</th>
                        </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                        {phaseEstimations.map((item) => (
                            <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                                <td className="p-3 font-medium text-text-primary">
                                    <div>{item.featureTask}</div>
                                    <div className="text-xs text-text-secondary">{item.subtask}</div>
                                </td>
                                <td className="p-3 font-bold text-text-primary">{item.estimatedHours}</td>
                                <td className="p-3 text-text-secondary">{item.complexity}</td>
                                <td className="p-3 text-text-secondary">{item.riskLevel}</td>
                                <td className="p-3 text-center">
                                    <button onClick={() => onViewHistory(item)} className="p-1.5 rounded-md hover:bg-slate-100" title="View History">
                                        <HistoryIcon className="w-4 h-4 text-text-secondary" />
                                    </button>
                                </td>
                                <td className="p-3">
                                    <div className="flex items-center justify-center gap-2">
                                        <button onClick={() => onEdit(item)} className="p-1.5 rounded-md hover:bg-slate-100" title="Edit Estimation"><PencilIcon className="w-4 h-4 text-text-secondary" /></button>
                                        <button onClick={() => onDelete(item)} className="p-1.5 rounded-md hover:bg-slate-100" title="Delete Estimation"><TrashIcon className="w-4 h-4 text-text-secondary" /></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-center text-text-secondary text-sm px-6 py-16">
            <p>No estimations created for this project yet.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectEstimations;
