import React from 'react';

// Simplified version of cva
const buttonVariants = {
  base: 'inline-flex items-center justify-center rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-card focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed',
  variants: {
    variant: {
      default: 'bg-primary text-white hover:bg-primary-hover',
      destructive: 'bg-red-600 text-white hover:bg-red-700',
      outline: 'bg-card text-text-primary border border-border hover:bg-slate-100',
      secondary: 'bg-secondary text-white hover:bg-pink-600',
      ghost: 'hover:bg-slate-100',
      link: 'text-primary underline-offset-4 hover:underline',
    },
    size: {
      default: 'h-10 py-2.5 px-5',
      sm: 'h-9 px-3 rounded-md',
      lg: 'h-11 px-8 rounded-md',
    },
  },
};

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: keyof typeof buttonVariants.variants.variant;
  size?: keyof typeof buttonVariants.variants.size;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'default', size = 'default', ...props }, ref) => {
    const classes = [
      buttonVariants.base,
      buttonVariants.variants.variant[variant],
      buttonVariants.variants.size[size],
      className,
    ].filter(Boolean).join(' ');
    
    return (
      <button
        className={classes}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = 'Button';

export { Button };
