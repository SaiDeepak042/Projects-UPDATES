import React from 'react';
import { XIcon } from '../icons/XIcon.tsx';

const Dialog = ({ isOpen, children, onClose }: { isOpen: boolean, children: React.ReactNode, onClose?: () => void }) => {
    if (!isOpen) return null;
    return (
        <div
            className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4 animate-fade-in"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
        >
            {children}
        </div>
    );
};

const DialogContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, children, ...props }, ref) => (
    <div
        ref={ref}
        className={`relative bg-card rounded-2xl shadow-2xl w-full max-w-lg border border-border transform animate-scale-in ${className}`}
        onClick={(e) => e.stopPropagation()}
        {...props}
    >
        {children}
    </div>
));
DialogContent.displayName = 'DialogContent';

const DialogHeader = ({ className, children }: React.HTMLAttributes<HTMLDivElement>) => (
    <div className={`flex items-center justify-between p-6 border-b border-border ${className}`}>
        {children}
    </div>
);
DialogHeader.displayName = 'DialogHeader';

const DialogFooter = ({ className, children }: React.HTMLAttributes<HTMLDivElement>) => (
    <div className={`px-6 py-4 bg-slate-50 border-t border-border flex justify-end gap-3 rounded-b-2xl ${className}`}>
        {children}
    </div>
);
DialogFooter.displayName = 'DialogFooter';

const DialogTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, children, ...props }, ref) => (
    <h2 ref={ref} className={`text-2xl font-bold text-text-primary ${className}`} {...props}>
        {children}
    </h2>
));
DialogTitle.displayName = 'DialogTitle';

const DialogDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, children, ...props }, ref) => (
    <p ref={ref} className={`text-sm text-text-secondary ${className}`} {...props}>
        {children}
    </p>
));
DialogDescription.displayName = 'DialogDescription';

const DialogCloseButton = ({ onClose }: { onClose: () => void }) => (
    <button 
        onClick={onClose} 
        className="p-2 rounded-full hover:bg-slate-100 text-text-secondary hover:text-text-primary transition"
        aria-label="Close modal"
    >
        <XIcon className="w-6 h-6" />
    </button>
);

export {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
  DialogCloseButton,
};
