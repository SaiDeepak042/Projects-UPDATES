import React from 'react';
import type { Project, User } from '../types/index.ts';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon.tsx';
import { CheckCircleIcon } from './icons/CheckCircleIcon.tsx';
import { CalendarIcon } from './icons/CalendarIcon.tsx';

interface ProjectHeaderProps {
  project: Project;
  onBack: () => void;
  teamMembers: User[];
}

const ProjectHeader: React.FC<ProjectHeaderProps> = ({ project, onBack, teamMembers }) => {
    const completedTasks = project.tasks.filter(t => t.status === 'Done').length;
    const totalTasks = project.tasks.length;
    const progress = project.progress;

  return (
    <div className="bg-card p-6 rounded-2xl border border-border shadow-card">
        <div className="flex justify-between items-start">
            <div className="flex items-center gap-4">
                 <button
                    onClick={onBack}
                    className="p-2 rounded-lg hover:bg-slate-100 text-text-secondary hover:text-text-primary transition self-start"
                    title="Back to projects"
                    >
                    <ArrowLeftIcon className="w-5 h-5" />
                </button>
                <div>
                    <h1 className="text-2xl font-bold text-text-primary">{project.name}</h1>
                    <p className="text-sm text-text-secondary mt-1 line-clamp-2 max-w-2xl">{project.description}</p>
                </div>
            </div>
             <div className="flex -space-x-2 flex-shrink-0 ml-4">
                {teamMembers.slice(0, 5).map(member => (
                    <img key={member.id} className="inline-block h-9 w-9 rounded-full ring-2 ring-card" src={member.avatar} alt={member.name} title={member.name}/>
                ))}
                {teamMembers.length > 5 && (
                    <div className="flex items-center justify-center h-9 w-9 rounded-full bg-border ring-2 ring-card text-xs font-semibold text-text-secondary">
                        +{teamMembers.length - 5}
                    </div>
                )}
            </div>
        </div>

        <div className="mt-6 pt-6 border-t border-border flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
             <div className="flex-1 w-full">
                <div className="flex justify-between items-center text-sm text-text-secondary mb-1">
                    <span>Progress</span>
                    <span className="font-semibold text-text-primary">{progress}%</span>
                </div>
                <div className="w-full bg-border rounded-full h-2">
                    <div className="bg-primary h-2 rounded-full" style={{ width: `${progress}%` }}></div>
                </div>
            </div>

            <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2 text-text-primary">
                    <CheckCircleIcon className="w-5 h-5 text-green-500" />
                    <div>
                        <span className="font-bold">{completedTasks}</span>
                        <span className="text-text-secondary">/{totalTasks} Tasks</span>
                    </div>
                </div>
                <div className="flex items-center gap-2 text-text-primary">
                    <CalendarIcon className="w-5 h-5 text-text-secondary" />
                     <div>
                        <span className="font-semibold">Due on:</span>
                        <span className="text-text-secondary"> {new Date(project.dueDate).toLocaleDateString()}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default ProjectHeader;