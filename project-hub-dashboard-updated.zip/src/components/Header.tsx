import React from 'react';
import type { User } from '../types/index.ts';
import { SearchIcon } from './icons/SearchIcon.tsx';
import { BellIcon } from './icons/BellIcon.tsx';

interface HeaderProps {
  currentUser: User;
  pageTitle: string;
}

const Header: React.FC<HeaderProps> = ({ currentUser, pageTitle }) => {

  return (
    <header className="bg-card p-4 border-b border-border flex items-center justify-between flex-shrink-0">
      <h1 className="text-xl font-bold text-text-primary">{pageTitle}</h1>
      <div className="flex items-center gap-4">
        <div className="relative w-64">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-text-tertiary" />
          <input
            type="text"
            placeholder="Search..."
            className="bg-background border border-border rounded-lg pl-10 pr-4 py-2 text-sm w-full text-text-primary placeholder-text-secondary focus:ring-2 focus:ring-primary focus:outline-none transition"
          />
        </div>
        <button className="relative text-text-secondary hover:text-text-primary transition-colors p-2 rounded-lg hover:bg-slate-100">
          <BellIcon className="w-6 h-6" />
          <span className="absolute top-1 right-1.5 flex h-2 w-2">
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
          </span>
        </button>
      </div>
    </header>
  );
};

export default Header;