import React from 'react';
import type { View, User } from '../types/index.ts';
import { DashboardIcon } from './icons/DashboardIcon.tsx';
import { ProjectsIcon } from './icons/ProjectsIcon.tsx';
import { TasksIcon } from './icons/TasksIcon.tsx';
import { TeamsIcon } from './icons/TeamsIcon.tsx';
import { LogoutIcon } from './icons/LogoutIcon.tsx';
import { ChevronDoubleLeftIcon } from './icons/ChevronDoubleLeftIcon.tsx';
import { DocumentIcon } from './icons/DocumentIcon.tsx';

interface SidebarProps {
  currentView: View;
  onViewChange: (view: View) => void;
  currentUser: User;
  onLogout: () => void;
  isCollapsed: boolean;
  onToggle: () => void;
}

const NavItem: React.FC<{
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  isCollapsed: boolean;
  onClick: () => void;
}> = ({ label, icon, isActive, isCollapsed, onClick }) => {
  return (
    <li>
      <a
        href="#"
        onClick={(e) => { e.preventDefault(); onClick(); }}
        title={isCollapsed ? label : undefined}
        className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-all relative ${
            isCollapsed ? 'justify-center' : ''
        } ${
          isActive 
            ? 'bg-primary/10 text-primary font-semibold' 
            : 'text-text-secondary hover:bg-slate-100 hover:text-text-primary'
        }`}
      >
        {isActive && !isCollapsed && <div className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-1 bg-primary rounded-r-full"></div>}
        {icon}
        {!isCollapsed && <span className="font-medium">{label}</span>}
      </a>
    </li>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange, currentUser, onLogout, isCollapsed, onToggle }) => {
    const canManage = new Set(['Director']).has(currentUser.designation);
    const canLead = new Set(['Software Developer', 'Design Automation Specialist', 'Product Configurator Specialist']).has(currentUser.designation);
    const isHr = new Set(['HR Generalist']).has(currentUser.designation);

    const canViewDashboard = canManage || canLead || isHr;
    const canViewTasks = !isHr;
    const canViewUsers = canManage || isHr;

  return (
    <aside className={`fixed top-0 left-0 h-full bg-card p-4 flex flex-col justify-between border-r border-border transition-all duration-300 ease-in-out z-30 ${isCollapsed ? 'w-20' : 'w-64'}`}>
      <div>
        <div className={`flex items-center space-x-3 mb-8 px-2 ${isCollapsed ? 'justify-center' : ''}`}>
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center font-bold text-xl text-white flex-shrink-0">
            PH
          </div>
          {!isCollapsed && <span className="text-xl font-bold text-text-primary whitespace-nowrap">Project Hub</span>}
        </div>
        <nav>
          <ul className="space-y-1">
            {canViewDashboard && <NavItem
              label="Dashboard"
              icon={<DashboardIcon className="w-6 h-6 flex-shrink-0" />}
              isActive={currentView === 'dashboard'}
              onClick={() => onViewChange('dashboard')}
              isCollapsed={isCollapsed}
            />}
            <NavItem
              label="Projects"
              icon={<ProjectsIcon className="w-6 h-6 flex-shrink-0" />}
              isActive={currentView === 'projects' || currentView === 'project-detail'}
              onClick={() => onViewChange('projects')}
              isCollapsed={isCollapsed}
            />
            {canViewTasks && <NavItem
              label="My Tasks"
              icon={<TasksIcon className="w-6 h-6 flex-shrink-0" />}
              isActive={currentView === 'tasks'}
              onClick={() => onViewChange('tasks')}
              isCollapsed={isCollapsed}
            />}
            <NavItem
              label="Templates"
              icon={<DocumentIcon className="w-6 h-6 flex-shrink-0" />}
              isActive={currentView === 'templates'}
              onClick={() => onViewChange('templates')}
              isCollapsed={isCollapsed}
            />
            {canViewUsers && <NavItem
              label="Users"
              icon={<TeamsIcon className="w-6 h-6 flex-shrink-0" />}
              isActive={currentView === 'users'}
              onClick={() => onViewChange('users')}
              isCollapsed={isCollapsed}
            />}
          </ul>
        </nav>
      </div>
      <div>
        <button 
            onClick={onToggle} 
            className="w-full flex items-center justify-center p-3 rounded-lg text-text-secondary hover:bg-slate-100 hover:text-text-primary transition-colors mb-2"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
            <ChevronDoubleLeftIcon className={`w-6 h-6 transition-transform duration-300 ${isCollapsed ? 'rotate-180' : ''}`} />
        </button>
        <div className="border-t border-border pt-4">
            <div className={`flex items-center gap-3 p-2 ${isCollapsed ? 'justify-center' : ''}`}>
                <img className="w-10 h-10 rounded-full flex-shrink-0" src={currentUser.avatar} alt={currentUser.name} />
                {!isCollapsed && (
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-text-primary truncate">{currentUser.name}</p>
                      <p className="text-xs text-text-secondary truncate">{currentUser.designation}</p>
                    </div>
                )}
                {!isCollapsed && (
                    <button onClick={onLogout} className="p-2 text-text-secondary hover:text-red-500 hover:bg-slate-100 rounded-lg transition-colors flex-shrink-0" title="Logout">
                        <LogoutIcon className="w-5 h-5" />
                    </button>
                )}
            </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;