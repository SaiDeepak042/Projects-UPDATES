import React from 'react';
import type { ScopeOfWork, User } from '../types/index.ts';
import { PlusIcon } from './icons/PlusIcon.tsx';
import { PencilIcon } from './icons/PencilIcon.tsx';
import { TrashIcon } from './icons/TrashIcon.tsx';
import { ArrowUpIcon } from './icons/ArrowUpIcon.tsx';
import { ArrowDownIcon } from './icons/ArrowDownIcon.tsx';
import { SortIcon } from './icons/SortIcon.tsx';

type SortableKeys = keyof ScopeOfWork;
type SortConfig = { key: SortableKeys; direction: 'ascending' | 'descending' } | null;

interface ScopeOfWorkListProps {
  scopeOfWorkItems: ScopeOfWork[];
  users: User[];
  teamMembers: User[];
  onAdd: () => void;
  onEdit: (scope: ScopeOfWork) => void;
  onDelete: (scope: ScopeOfWork) => void;
  sortConfig: SortConfig;
  requestSort: (key: SortableKeys) => void;
  filters: { responsibleParty: string };
  setFilters: (filters: { responsibleParty: string }) => void;
}

const ScopeOfWorkList: React.FC<ScopeOfWorkListProps> = (props) => {
    const { 
      scopeOfWorkItems, users, teamMembers, onAdd, onEdit, onDelete,
      sortConfig, requestSort, filters, setFilters 
    } = props;
    
    const getUserName = (userId: string) => {
        return users.find(u => u.id === userId)?.name || 'Unknown';
    }

    const getSortIcon = (key: SortableKeys) => {
        if (!sortConfig || sortConfig.key !== key) return <SortIcon className="w-3 h-3" />;
        return sortConfig.direction === 'ascending' ? <ArrowUpIcon className="w-3 h-3" /> : <ArrowDownIcon className="w-3 h-3" />;
    }

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setFilters({ responsibleParty: e.target.value });
    };

  return (
    <div className="bg-card rounded-b-2xl h-full flex flex-col">
      <div className="p-4 flex justify-between items-center border-b border-border">
        <h2 className="text-lg font-bold text-text-primary">Scope of Work</h2>
        <button
          onClick={onAdd}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-primary bg-primary/10 rounded-md hover:bg-primary/20 transition-colors"
        >
          <PlusIcon className="w-4 h-4" />
          Add Item
        </button>
      </div>
      <div className="p-3 flex items-center gap-4 border-b border-border bg-slate-50/50">
        <div className="flex items-center gap-2">
            <label htmlFor="responsible-party-filter" className="text-xs font-medium text-text-secondary">Responsible Party:</label>
            <select name="responsibleParty" id="responsible-party-filter" value={filters.responsibleParty} onChange={handleFilterChange} className="bg-card border border-border rounded-md px-2 py-1 text-xs">
                <option value="">All</option>
                {teamMembers.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
        </div>
      </div>
      <div className="flex-1 overflow-x-auto">
        {scopeOfWorkItems.length > 0 ? (
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50">
              <tr className="border-b border-border">
                {(Object.keys(scopeOfWorkItems[0] || {}) as SortableKeys[]).filter(k => k !== 'id' && k !== 'projectId').map(key => (
                  <th key={key} className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider whitespace-nowrap cursor-pointer" onClick={() => requestSort(key)}>
                    <div className="flex items-center gap-1">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} {getSortIcon(key)}</div>
                  </th>
                ))}
                <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {scopeOfWorkItems.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 text-text-primary whitespace-nowrap">{item.scopeOfWork}</td>
                  <td className="p-3 text-text-primary whitespace-nowrap">{item.featureModule}</td>
                  <td className="p-3 text-text-primary whitespace-nowrap">{item.taskSubtask}</td>
                  <td className="p-3 text-text-secondary max-w-xs truncate">{item.description}</td>
                  <td className="p-3 text-text-secondary max-w-xs truncate">{item.deliverables}</td>
                  <td className="p-3 text-text-secondary max-w-xs truncate">{item.acceptanceCriteria}</td>
                  <td className="p-3 text-text-primary font-semibold text-center">{item.estimatedEffort}</td>
                  <td className="p-3 text-text-secondary whitespace-nowrap">{item.dependencies}</td>
                  <td className="p-3 text-text-primary whitespace-nowrap">{getUserName(item.responsibleParty)}</td>
                  <td className="p-3 text-text-primary whitespace-nowrap">{item.priority}</td>
                  <td className="p-3 text-text-primary whitespace-nowrap">{item.riskLevel}</td>
                  <td className="p-3 text-text-secondary max-w-xs truncate">{item.notes}</td>
                  <td className="p-3">
                    <div className="flex items-center justify-center gap-2">
                      <button onClick={() => onEdit(item)} className="p-1.5 rounded-md hover:bg-slate-100" title="Edit Item"><PencilIcon className="w-4 h-4 text-text-secondary" /></button>
                      <button onClick={() => onDelete(item)} className="p-1.5 rounded-md hover:bg-slate-100" title="Delete Item"><TrashIcon className="w-4 h-4 text-text-secondary" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="flex items-center justify-center h-full text-center text-text-secondary text-sm px-6 py-16">
            <p>No Scope of Work items match the current filters.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ScopeOfWorkList;
