import React from 'react';
import type { Project, User } from '../types/index.ts';
import { Card } from './ui/card.tsx';
import { MoreHorizontalIcon } from './icons/MoreHorizontalIcon.tsx';
import { PencilIcon } from './icons/PencilIcon.tsx';
import { TrashIcon } from './icons/TrashIcon.tsx';

interface ProjectCardProps {
  project: Project;
  currentUser: User;
  onDelete: () => void;
  onView: () => void;
  onEdit: () => void;
}

const getStatusClass = (status: Project['status']) => {
  switch (status) {
    case 'In Progress': return 'bg-blue-100 text-blue-800';
    case 'Completed': return 'bg-green-100 text-green-800';
    case 'On Hold': return 'bg-yellow-100 text-yellow-800';
    case 'Cancelled': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

const ProjectCard: React.FC<ProjectCardProps> = ({ project, currentUser, onDelete, onView, onEdit }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  
  const handleEditClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      onEdit();
      setIsMenuOpen(false);
  }
  
  const handleDeleteClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      onDelete();
      setIsMenuOpen(false);
  }

  const canEdit = new Set(['Director', 'Software Developer', 'Design Automation Specialist', 'Product Configurator Specialist']).has(currentUser.designation);

  return (
    <Card 
      className="p-5 flex flex-col justify-between hover:shadow-card-hover hover:border-primary/30 transition-all duration-300 transform hover:-translate-y-1 cursor-pointer" 
      onClick={onView}
    >
      <div>
        <div className="flex justify-between items-start">
          <div>
            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusClass(project.status)}`}>
              {project.status}
            </span>
          </div>
          {canEdit && (
            <div className="relative" onClick={(e) => e.stopPropagation()}>
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)} 
                className="text-text-secondary hover:text-text-primary p-1 rounded-full hover:bg-slate-100"
              >
                <MoreHorizontalIcon className="w-5 h-5" />
              </button>
              {isMenuOpen && (
                <div className="absolute right-0 mt-2 w-40 bg-card border border-border rounded-lg shadow-xl z-10">
                  <button onClick={handleEditClick} className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-text-primary hover:bg-slate-100">
                    <PencilIcon className="w-4 h-4" /> Edit Project
                  </button>
                  <button onClick={handleDeleteClick} className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-red-500 hover:bg-slate-100">
                    <TrashIcon className="w-4 h-4" /> Delete Project
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        <h3 className="text-base font-bold text-text-primary mt-3">{project.name}</h3>
        <p className="text-sm text-text-secondary mt-1 line-clamp-2 h-10">{project.description}</p>
      </div>

      <div className="mt-6">
        <div className="flex justify-between items-center text-xs text-text-secondary mb-1">
          <span>Progress</span>
          <span className="font-semibold text-text-primary">{project.progress}%</span>
        </div>
        <div className="w-full bg-border rounded-full h-1.5">
          <div className="bg-primary h-1.5 rounded-full" style={{ width: `${project.progress}%` }}></div>
        </div>
        <div className="flex justify-between items-center mt-4">
          <div className="flex -space-x-2">
            {project.teamMemberIds.slice(0, 3).map(memberId => (
              <img key={memberId} className="inline-block h-8 w-8 rounded-full ring-2 ring-card" src={`https://i.pravatar.cc/40?u=${memberId}`} alt={`Team member ${memberId}`} />
            ))}
            {project.teamMemberIds.length > 3 && (
              <div className="flex items-center justify-center h-8 w-8 rounded-full bg-border ring-2 ring-card text-xs font-semibold text-text-secondary">
                +{project.teamMemberIds.length - 3}
              </div>
            )}
          </div>
          <div className="text-right">
             <p className="text-xs text-text-secondary">Due Date</p>
             <p className="text-sm font-medium text-text-primary">{new Date(project.dueDate).toLocaleDateString()}</p>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default ProjectCard;