import React from 'react';
import type { ClientInput } from '../types/index.ts';
import { PlusIcon } from './icons/PlusIcon.tsx';
import { ArrowUpIcon } from './icons/ArrowUpIcon.tsx';
import { ArrowDownIcon } from './icons/ArrowDownIcon.tsx';
import { SortIcon } from './icons/SortIcon.tsx';

type SortableKeys = 'requestedOn' | 'requestedBy' | 'status';
type SortConfig = { key: SortableKeys; direction: 'ascending' | 'descending' } | null;


interface ClientInputsListProps {
  clientInputs: ClientInput[];
  onAdd: () => void;
  onEdit: (input: ClientInput) => void;
  onDelete: (input: ClientInput) => void;
  sortConfig: SortConfig;
  requestSort: (key: SortableKeys) => void;
  filters: { status: string };
  setFilters: (filters: { status: string }) => void;
}

const getStatusClass = (status: ClientInput['status']) => {
  switch (status) {
    case 'Pending': return 'bg-yellow-100 text-yellow-800';
    case 'Completed': return 'bg-green-100 text-green-800';
    case 'On Hold': return 'bg-orange-100 text-orange-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};


const ClientInputsList: React.FC<ClientInputsListProps> = ({ 
  clientInputs, onAdd, onEdit, onDelete, sortConfig, requestSort, filters, setFilters 
}) => {
  
  const getSortIcon = (key: SortableKeys) => {
    if (!sortConfig || sortConfig.key !== key) return <SortIcon className="w-3 h-3" />;
    return sortConfig.direction === 'ascending' ? <ArrowUpIcon className="w-3 h-3" /> : <ArrowDownIcon className="w-3 h-3" />;
  }

  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilters({ status: e.target.value });
  };
  
  return (
    <div className="bg-card rounded-b-2xl h-full flex flex-col">
      <div className="p-4 flex justify-between items-center border-b border-border">
        <h2 className="text-lg font-bold text-text-primary">Client Input Requests</h2>
        <button
          onClick={onAdd}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-primary bg-primary/10 rounded-md hover:bg-primary/20 transition-colors"
        >
          <PlusIcon className="w-4 h-4" />
          Add Request
        </button>
      </div>
       <div className="p-3 flex items-center gap-4 border-b border-border bg-slate-50/50">
        <div className="flex items-center gap-2">
            <label htmlFor="status-filter" className="text-xs font-medium text-text-secondary">Status:</label>
            <select name="status" id="status-filter" value={filters.status} onChange={handleFilterChange} className="bg-card border border-border rounded-md px-2 py-1 text-xs">
                <option value="">All</option>
                <option>Pending</option>
                <option>Completed</option>
                <option>On Hold</option>
            </select>
        </div>
      </div>
      <div className="flex-1 overflow-x-auto">
        {clientInputs.length > 0 ? (
           <table className="w-full text-sm text-left">
             <thead className="bg-slate-50">
                 <tr className="border-b border-border">
                     <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider text-center">#</th>
                     <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider">Description</th>
                     <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('requestedOn')}>
                        <div className="flex items-center gap-1">Requested On {getSortIcon('requestedOn')}</div>
                     </th>
                     <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('requestedBy')}>
                        <div className="flex items-center gap-1">Requested By {getSortIcon('requestedBy')}</div>
                     </th>
                     <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider">Received On</th>
                     <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider">Assignee</th>
                     <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('status')}>
                        <div className="flex items-center gap-1">Status {getSortIcon('status')}</div>
                     </th>
                     <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider text-center">Actions</th>
                 </tr>
             </thead>
             <tbody className="divide-y divide-border">
                {clientInputs.map((input, index) => (
                    <tr key={input.id} className="hover:bg-slate-50 transition-colors text-text-primary">
                        <td className="p-3 font-medium text-center text-text-secondary">{index + 1}</td>
                        <td className="p-3 font-medium">{input.description}</td>
                        <td className="p-3 whitespace-nowrap">{new Date(input.requestedOn).toLocaleDateString()}</td>
                        <td className="p-3 whitespace-nowrap">{input.requestedBy}</td>
                        <td className="p-3 whitespace-nowrap">{input.receivedOn ? new Date(input.receivedOn).toLocaleDateString() : '-'}</td>
                        <td className="p-3 whitespace-nowrap">{input.assignee || '-'}</td>
                        <td className="p-3">
                           <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusClass(input.status)}`}>
                                {input.status}
                           </span>
                        </td>
                        <td className="p-3">
                            <div className="flex items-center justify-center gap-2">
                                <button onClick={() => onEdit(input)} className="px-3 py-1 text-xs font-medium rounded-md bg-card text-text-primary border border-border hover:bg-slate-100 transition">
                                    Edit
                                </button>
                                <button onClick={() => onDelete(input)} className="px-3 py-1 text-xs font-medium rounded-md bg-card text-text-primary border border-border hover:bg-red-50 hover:text-red-600 transition">
                                    Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                ))}
            </tbody>
           </table>
        ) : (
          <div className="flex items-center justify-center h-full text-center text-text-secondary text-sm px-6 py-16">
            <p>No client input requests match the current filters.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientInputsList;
