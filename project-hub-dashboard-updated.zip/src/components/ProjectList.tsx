import React from 'react';
import type { Project, View } from '../types/index.ts';
import { MoreHorizontalIcon } from './icons/MoreHorizontalIcon.tsx';

interface ProjectListProps {
  projects: Project[];
  onViewChange: (view: View) => void;
  onViewProject: (project: Project) => void;
}

const getStatusClass = (status: Project['status']) => {
  switch (status) {
    case 'In Progress': return 'bg-blue-100 text-blue-800';
    case 'Completed': return 'bg-green-100 text-green-800';
    case 'On Hold': return 'bg-yellow-100 text-yellow-800';
    case 'Cancelled': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

const ProjectList: React.FC<ProjectListProps> = ({ projects, onViewChange, onViewProject }) => {
  return (
    <div className="bg-card p-6 rounded-2xl shadow-card border border-border h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold text-text-primary">Recent Projects</h2>
        <button onClick={() => onViewChange('projects')} className="text-sm font-medium text-primary hover:underline">View All</button>
      </div>
      <div className="space-y-2">
        {projects.map(project => (
          <div 
            key={project.id} 
            className="p-3 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            onClick={() => onViewProject(project)}
          >
            <div className="flex items-center justify-between">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-text-primary truncate">{project.name}</p>
                <div className="flex items-center gap-4 text-sm text-text-secondary mt-1">
                  <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getStatusClass(project.status)}`}>
                    {project.status}
                  </span>
                  <span>Due: {new Date(project.dueDate).toLocaleDateString()}</span>
                </div>
              </div>
              <div className="flex items-center gap-4 ml-4">
                <div className="flex -space-x-2">
                    {project.teamMemberIds.slice(0, 3).map(memberId => (
                        <img key={memberId} className="inline-block h-8 w-8 rounded-full ring-2 ring-card" src={`https://i.pravatar.cc/40?u=${memberId}`} alt={`Team member ${memberId}`} />
                    ))}
                    {project.teamMemberIds.length > 3 && (
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-border ring-2 ring-card text-xs font-semibold text-text-secondary">
                            +{project.teamMemberIds.length - 3}
                        </div>
                    )}
                </div>
                 <div className="w-24 text-right">
                    <span className="text-sm font-medium text-text-primary">{project.progress}%</span>
                     <div className="w-full bg-border rounded-full h-1.5 mt-1">
                        <div className="bg-primary h-1.5 rounded-full" style={{ width: `${project.progress}%` }}></div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProjectList;