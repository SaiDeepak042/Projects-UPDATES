import React from 'react';
import type { User } from '../types/index.ts';

interface ProjectTeamCardProps {
  leader?: User;
  teamMembers: User[];
}

const ProjectTeamCard: React.FC<ProjectTeamCardProps> = ({ leader, teamMembers }) => {
  return (
    <div className="bg-card rounded-2xl border border-border p-5 shadow-card">
      <h2 className="text-lg font-bold text-text-primary mb-4">Project Team</h2>
      <div className="space-y-4">
        {leader && (
          <div>
            <h3 className="text-xs font-semibold text-text-secondary uppercase mb-2">Team Leader</h3>
            <div className="flex items-center gap-3">
              <img src={leader.avatar} alt={leader.name} className="w-10 h-10 rounded-full" />
              <div>
                <p className="font-semibold text-text-primary text-sm">{leader.name}</p>
                <p className="text-xs text-text-secondary">{leader.email}</p>
              </div>
            </div>
          </div>
        )}
        <div>
           <h3 className="text-xs font-semibold text-text-secondary uppercase mb-2">Team Members</h3>
           <ul className="space-y-3">
            {teamMembers.filter(m => m.id !== leader?.id).map(member => (
                 <li key={member.id} className="flex items-center gap-3">
                    <img src={member.avatar} alt={member.name} className="w-9 h-9 rounded-full" />
                    <div>
                        <p className="font-medium text-text-primary text-sm">{member.name}</p>
                        {/* FIX: Replaced `member.role` with `member.designation` as the 'role' property does not exist on the User type. */}
                        <p className="text-xs text-text-secondary">{member.designation}</p>
                    </div>
                 </li>
            ))}
           </ul>
        </div>
      </div>
    </div>
  );
};

export default ProjectTeamCard;