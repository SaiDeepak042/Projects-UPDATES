import React from 'react';
export const FilePptIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M14 2H6C4.9 2 4 2.9 4 4V20C4 21.1 4.9 22 6 22H18C19.1 22 20 21.1 20 20V8L14 2Z" fill="#D24726"/>
        <path d="M14 2V8H20L14 2Z" fill="#8C2F19"/>
        <text x="12" y="16" fontFamily="Arial, sans-serif" fontSize="6" fill="white" textAnchor="middle" fontWeight="bold">PPT</text>
    </svg>
);
