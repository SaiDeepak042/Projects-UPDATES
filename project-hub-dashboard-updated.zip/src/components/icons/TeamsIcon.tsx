import React from 'react';

export const TeamsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.962c.57-1.023-.09-2.277-1.344-2.722-1.254-.445-2.692.23-3.262 1.255a9.04 9.04 0 00-1.88 4.132m12.36-1.341a9.043 9.043 0 01-1.14 1.341m-10.092-2.482a9.042 9.042 0 01-.823.515m12.36-1.341a9.043 9.043 0 00-1.14-1.341m-10.092 2.482c.212.136.43.262.654.381m7.816-5.201a9.043 9.043 0 01-1.826.92m-6.445-2.189a9.043 9.043 0 011.826-.92m3.652 4.043a9.043 9.043 0 01-1.14 1.341m-3.328-2.482a9.043 9.043 0 00-1.14-1.341" />
  </svg>
);