import React from 'react';
import type { Meeting, User } from '../types/index.ts';
import { PlusIcon } from './icons/PlusIcon.tsx';

interface MeetingsListProps {
  meetings: Meeting[];
  users: User[];
  onAdd: () => void;
}

const MeetingsList: React.FC<MeetingsListProps> = ({ meetings, users, onAdd }) => {
  const getAttendeeAvatar = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.avatar : `https://i.pravatar.cc/40?u=${userId}`;
  };
  
  const sortedMeetings = [...meetings].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="bg-card rounded-2xl border border-border shadow-card">
      <div className="p-4 flex justify-between items-center border-b border-border">
        <h2 className="text-lg font-bold text-text-primary">Meetings</h2>
        <button
          onClick={onAdd}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-primary bg-primary/10 rounded-md hover:bg-primary/20 transition-colors"
        >
          <PlusIcon className="w-4 h-4" />
          Schedule
        </button>
      </div>
      <div className="p-4 space-y-3">
        {sortedMeetings.length > 0 ? (
          sortedMeetings.map(meeting => (
            <div key={meeting.id} className="p-3 rounded-lg bg-slate-50 border border-border/50">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold text-text-primary text-sm">{meeting.title}</p>
                  <p className="text-xs text-text-secondary mt-1">
                    {new Date(meeting.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} at {meeting.time}
                  </p>
                </div>
                <div className="flex -space-x-2">
                  {meeting.attendees.slice(0, 3).map(attId => (
                    <img key={attId} className="inline-block h-6 w-6 rounded-full ring-2 ring-slate-50" src={getAttendeeAvatar(attId)} alt={`Attendee`} />
                  ))}
                   {meeting.attendees.length > 3 && (
                        <div className="flex items-center justify-center h-6 w-6 rounded-full bg-border ring-2 ring-slate-50 text-xs font-semibold text-text-secondary">
                            +{meeting.attendees.length - 3}
                        </div>
                    )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-sm text-text-secondary py-8">No meetings scheduled.</p>
        )}
      </div>
    </div>
  );
};

export default MeetingsList;