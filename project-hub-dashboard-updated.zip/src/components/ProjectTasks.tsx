import React from 'react';
import type { Task, User, TaskPriority, TaskStatusName } from '../types/index.ts';
import { PlusIcon } from './icons/PlusIcon.tsx';
import { PencilIcon } from './icons/PencilIcon.tsx';
import { TrashIcon } from './icons/TrashIcon.tsx';
import { ArrowUpIcon } from './icons/ArrowUpIcon.tsx';
import { ArrowDownIcon } from './icons/ArrowDownIcon.tsx';
import { SortIcon } from './icons/SortIcon.tsx';

type SortableTaskKeys = 'title' | 'assigneeId' | 'priority' | 'dueDate';
type SortConfig = { key: SortableTaskKeys; direction: 'ascending' | 'descending' } | null;

interface ProjectTasksProps {
  tasks: Task[];
  users: User[];
  teamMembers: User[];
  onAddTask: () => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (task: Task) => void;
  onViewTask: (task: Task) => void;
  sortConfig: SortConfig;
  requestSort: (key: SortableTaskKeys) => void;
  filters: { assigneeId: string, status: string };
  setFilters: (filters: { assigneeId: string, status: string }) => void;
}


const COLORS = ['#22c55e', '#ef4444', '#f97316', '#3b82fd', '#6366f1', '#a855f7', '#ec4899', '#14b8a6'];
const getAvatarInfo = (name: string) => {
    const initials = name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
    const charCodeSum = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const color = COLORS[charCodeSum % COLORS.length];
    return { initials, color };
};
const getPriorityClass = (priority: TaskPriority) => {
    switch(priority) {
        case 'High': return 'text-red-600';
        case 'Medium': return 'text-amber-600';
        case 'Low': return 'text-blue-600';
        default: return 'text-text-primary';
    }
};
const getStatusClass = (status: TaskStatusName) => {
    switch(status) {
        case 'To Do': return 'bg-slate-100 text-slate-700';
        case 'In Progress': return 'bg-blue-100 text-blue-700';
        case 'Review': return 'bg-amber-100 text-amber-700';
        case 'Done': return 'bg-green-100 text-green-700';
        case 'New': return 'bg-indigo-100 text-indigo-700';
        default: return 'bg-slate-100 text-slate-700';
    }
}

const ProjectTasks: React.FC<ProjectTasksProps> = (props) => {
    const { 
        tasks, users, teamMembers, onAddTask, onEditTask, onDeleteTask, onViewTask, 
        sortConfig, requestSort, filters, setFilters 
    } = props;
    
    const getAssignee = (assigneeId: string) => users.find(u => u.id === assigneeId);

    const getSortIcon = (key: SortableTaskKeys) => {
        if (!sortConfig || sortConfig.key !== key) return <SortIcon className="w-4 h-4" />;
        return sortConfig.direction === 'ascending' ? <ArrowUpIcon className="w-4 h-4" /> : <ArrowDownIcon className="w-4 h-4" />;
    }
    
    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters({ ...filters, [name]: value });
    };

  return (
    <div className="bg-card rounded-b-2xl h-full flex flex-col">
      <div className="p-4 flex justify-between items-center border-b border-border">
        <h2 className="text-lg font-bold text-text-primary">Project Tasks</h2>
        <button
          onClick={onAddTask}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-primary bg-primary/10 rounded-md hover:bg-primary/20 transition-colors"
        >
          <PlusIcon className="w-4 h-4" />
          Add Task
        </button>
      </div>
      
      <div className="p-3 flex items-center gap-4 border-b border-border bg-slate-50/50">
        <div className="flex items-center gap-2">
            <label htmlFor="assignee-filter" className="text-xs font-medium text-text-secondary">Assignee:</label>
            <select name="assigneeId" id="assignee-filter" value={filters.assigneeId} onChange={handleFilterChange} className="bg-card border border-border rounded-md px-2 py-1 text-xs">
                <option value="">All</option>
                {teamMembers.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
        </div>
        <div className="flex items-center gap-2">
            <label htmlFor="status-filter" className="text-xs font-medium text-text-secondary">Status:</label>
            <select name="status" id="status-filter" value={filters.status} onChange={handleFilterChange} className="bg-card border border-border rounded-md px-2 py-1 text-xs">
                <option value="">All</option>
                <option>New</option><option>To Do</option><option>In Progress</option><option>Review</option><option>Done</option>
            </select>
        </div>
      </div>

      <div className="flex-1 overflow-x-auto">
        {tasks.length > 0 ? (
           <table className="w-full text-sm text-left">
             <thead className="bg-slate-50">
                 <tr>
                    <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('title')}>
                        <div className="flex items-center gap-1">Task {getSortIcon('title')}</div>
                    </th>
                    <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider">Status</th>
                    <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('assigneeId')}>
                        <div className="flex items-center gap-1">Assignee {getSortIcon('assigneeId')}</div>
                    </th>
                    <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('priority')}>
                        <div className="flex items-center gap-1">Priority {getSortIcon('priority')}</div>
                    </th>
                    <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider cursor-pointer" onClick={() => requestSort('dueDate')}>
                        <div className="flex items-center gap-1">Due Date {getSortIcon('dueDate')}</div>
                    </th>
                    <th className="p-3 text-xs font-semibold text-text-secondary uppercase tracking-wider text-center">Actions</th>
                 </tr>
             </thead>
             <tbody className="divide-y divide-border">
                {tasks.map((task) => {
                    const assignee = getAssignee(task.assigneeId);
                    const avatarInfo = assignee ? getAvatarInfo(assignee.name) : {initials: '?', color: '#94a3b8'};
                    return(
                    <tr key={task.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-semibold text-text-primary cursor-pointer" onClick={() => onViewTask(task)}>{task.title}</td>
                        <td className="p-3">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(task.status)}`}>{task.status}</span>
                        </td>
                        <td className="p-3">
                            {assignee && (
                                <div className="flex items-center gap-2">
                                    <div style={{ backgroundColor: avatarInfo.color }} className="w-6 h-6 rounded-full flex items-center justify-center text-white text-[10px] font-bold">
                                        {avatarInfo.initials}
                                    </div>
                                    <span className="text-text-primary text-sm">{assignee.name}</span>
                                </div>
                            )}
                        </td>
                        <td className={`p-3 font-medium ${getPriorityClass(task.priority)}`}>{task.priority}</td>
                        <td className="p-3 text-text-secondary">{new Date(task.dueDate).toLocaleDateString()}</td>
                        <td className="p-3">
                            <div className="flex items-center justify-center gap-2">
                                <button onClick={() => onEditTask(task)} className="p-1.5 rounded-md hover:bg-slate-100" title="Edit Task"><PencilIcon className="w-4 h-4 text-text-secondary" /></button>
                                <button onClick={() => onDeleteTask(task)} className="p-1.5 rounded-md hover:bg-slate-100" title="Delete Task"><TrashIcon className="w-4 h-4 text-text-secondary" /></button>
                            </div>
                        </td>
                    </tr>
                )})}
            </tbody>
           </table>
        ) : (
          <div className="flex items-center justify-center h-full text-center text-text-secondary text-sm px-6 py-16">
            <p>No tasks match the current filters.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectTasks;
