import React from 'react';
import type { User, View, Project } from '../types/index.ts';

interface TeamOverviewProps {
  users: User[];
  projects: Project[];
  onViewChange: (view: View) => void;
}

const TeamOverview: React.FC<TeamOverviewProps> = ({ users, projects, onViewChange }) => {
  return (
    <div className="bg-card p-6 rounded-2xl shadow-card border border-border h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold text-text-primary">Team Overview</h2>
        <button onClick={() => onViewChange('users')} className="text-sm font-medium text-primary hover:underline">View All</button>
      </div>
      <ul className="space-y-4">
        {users.slice(0, 4).map(user => {
          const userProjects = projects.filter(p => p.leaderId === user.id || p.teamMemberIds.includes(user.id));
          return (
             <li key={user.id} className="flex items-start gap-3">
              <img className="w-9 h-9 rounded-full flex-shrink-0" src={user.avatar} alt={user.name} />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-text-primary truncate">{user.name}</p>
                <p className="text-xs text-text-secondary truncate">{user.designation}</p>
                <div className="mt-2 space-y-1">
                  {userProjects.length > 0 ? (
                    userProjects.map(project => {
                      const taskCount = project.tasks.filter(task => task.assigneeId === user.id).length;
                      return (
                        <div key={project.id} className="flex items-center justify-between text-xs bg-slate-50/70 p-1.5 rounded">
                          <div className="flex-1 min-w-0">
                            <p className="text-text-secondary font-medium truncate">{project.name}</p>
                            <p className="text-text-tertiary truncate">{taskCount} assigned task{taskCount !== 1 ? 's' : ''}</p>
                          </div>
                          <span className={`ml-2 flex-shrink-0 font-semibold px-1.5 py-0.5 rounded text-[10px] ${project.leaderId === user.id ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>
                            {project.leaderId === user.id ? 'Leader' : 'Member'}
                          </span>
                        </div>
                      )
                    })
                  ) : (
                    <p className="text-xs text-text-tertiary italic">No active projects</p>
                  )}
                </div>
              </div>
            </li>
          )
        })}
      </ul>
    </div>
  );
};

export default TeamOverview;