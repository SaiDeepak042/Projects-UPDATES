import React from 'react';
import type { Activity, User } from '../types/index.ts';
import { ActivityActionType } from '../types/index.ts';
import { FolderPlusIcon } from './icons/FolderPlusIcon.tsx';
import { PencilSquareIcon } from './icons/PencilSquareIcon.tsx';
import { CheckCircleIcon } from './icons/CheckCircleIcon.tsx';
import { TrashIcon } from './icons/TrashIcon.tsx';
import { VideoCameraIcon } from './icons/VideoCameraIcon.tsx';
import { ClipboardListIcon } from './icons/ClipboardListIcon.tsx';
import { CalculatorIcon } from './icons/CalculatorIcon.tsx';
import { DocumentTextIcon } from './icons/DocumentTextIcon.tsx';

interface ActivityFeedProps {
  activities: Activity[];
  allUsers: User[];
  title?: string;
}

const getActivityIcon = (actionType: ActivityActionType) => {
    const iconClass = "w-5 h-5";
    switch(actionType) {
        case ActivityActionType.PROJECT_CREATED:
            return <div className="bg-blue-100 p-1.5 rounded-full"><FolderPlusIcon className={`${iconClass} text-blue-600`} /></div>;
        case ActivityActionType.PROJECT_UPDATED:
        case ActivityActionType.TASK_UPDATED:
        case ActivityActionType.INPUT_UPDATED:
            return <div className="bg-amber-100 p-1.5 rounded-full"><PencilSquareIcon className={`${iconClass} text-amber-600`} /></div>;
        case ActivityActionType.TASK_CREATED:
            return <div className="bg-green-100 p-1.5 rounded-full"><CheckCircleIcon className={`${iconClass} text-green-600`} /></div>;
        case ActivityActionType.TASK_DELETED:
        case ActivityActionType.INPUT_DELETED:
        case ActivityActionType.ESTIMATION_DELETED:
        case ActivityActionType.SCOPE_DELETED:
             return <div className="bg-red-100 p-1.5 rounded-full"><TrashIcon className={`${iconClass} text-red-600`} /></div>;
        case ActivityActionType.MEETING_CREATED:
             return <div className="bg-purple-100 p-1.5 rounded-full"><VideoCameraIcon className={`${iconClass} text-purple-600`} /></div>;
        case ActivityActionType.INPUT_CREATED:
            return <div className="bg-cyan-100 p-1.5 rounded-full"><ClipboardListIcon className={`${iconClass} text-cyan-600`} /></div>;
        case ActivityActionType.ESTIMATION_CREATED:
        case ActivityActionType.ESTIMATION_UPDATED:
            return <div className="bg-lime-100 p-1.5 rounded-full"><CalculatorIcon className={`${iconClass} text-lime-600`} /></div>;
        case ActivityActionType.SCOPE_CREATED:
        case ActivityActionType.SCOPE_UPDATED:
            return <div className="bg-teal-100 p-1.5 rounded-full"><DocumentTextIcon className={`${iconClass} text-teal-600`} /></div>;
        default:
            return <div className="bg-slate-100 p-1.5 rounded-full"><PencilSquareIcon className={`${iconClass} text-slate-600`} /></div>;
    }
}

const formatActivityText = (activity: Activity, user?: User) => {
    const userName = user ? `<strong>${user.name}</strong>` : 'Someone';
    const { details } = activity;

    switch (activity.actionType) {
        case ActivityActionType.PROJECT_CREATED:
            return `${userName} created the project "${details.projectName}"`;
        case ActivityActionType.PROJECT_UPDATED:
            return `${userName} updated the project "${details.projectName}"`;
        case ActivityActionType.TASK_CREATED:
            return `${userName} created a new task: "${details.taskTitle}"`;
        case ActivityActionType.TASK_UPDATED:
            return `${userName} updated the task "${details.taskTitle}"`;
        case ActivityActionType.TASK_DELETED:
            return `${userName} deleted the task "${details.taskTitle}"`;
        case ActivityActionType.INPUT_CREATED:
            return `${userName} added a client input: "${details.inputDescription}"`;
        case ActivityActionType.INPUT_UPDATED:
            return `${userName} updated a client input: "${details.inputDescription}"`;
        case ActivityActionType.INPUT_DELETED:
            return `${userName} deleted a client input: "${details.inputDescription}"`;
        case ActivityActionType.MEETING_CREATED:
            return `${userName} scheduled a meeting: "${details.meetingTitle}"`;
        case ActivityActionType.ESTIMATION_CREATED:
            return `${userName} created an estimation: "${details.estimationTitle}"`;
        case ActivityActionType.ESTIMATION_UPDATED:
            return `${userName} updated an estimation: "${details.estimationTitle}"`;
        case ActivityActionType.ESTIMATION_DELETED:
            return `${userName} deleted an estimation: "${details.estimationTitle}"`;
        case ActivityActionType.SCOPE_CREATED:
            return `${userName} added a scope of work item: "${details.scopeTitle}"`;
        case ActivityActionType.SCOPE_UPDATED:
            return `${userName} updated a scope of work item: "${details.scopeTitle}"`;
        case ActivityActionType.SCOPE_DELETED:
            return `${userName} deleted a scope of work item: "${details.scopeTitle}"`;
        default:
            return `An action was performed.`;
    }
}

const ActivityFeed: React.FC<ActivityFeedProps> = ({ activities, allUsers, title = "Activity Feed" }) => {
  const getUserById = (id: string): User | undefined => allUsers.find(u => u.id === id);

  return (
    <div className="bg-card p-6 rounded-2xl shadow-card border border-border h-full">
      <h2 className="text-lg font-bold text-text-primary mb-4">{title}</h2>
      {activities.length > 0 ? (
        <ul className="space-y-4">
          {activities.map(activity => {
            const user = getUserById(activity.userId);
            return (
              <li key={activity.id} className="flex items-start gap-3">
                <div className="flex-shrink-0">
                  {getActivityIcon(activity.actionType)}
                </div>
                <div className="flex-1">
                  <p className="text-sm text-text-primary" dangerouslySetInnerHTML={{ __html: formatActivityText(activity, user) }}></p>
                  <p className="text-xs text-text-secondary mt-0.5">
                    {new Date(activity.timestamp).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="text-sm text-text-secondary text-center py-8">No recent activity.</p>
      )}
    </div>
  );
};

export default ActivityFeed;