// FIX: Removed `/// <reference types="vite/client" />` to resolve a type definition error.
// The types provided by this directive were not in use in the project, making this removal safe.
// This error typically points to a configuration issue in `tsconfig.json`.
