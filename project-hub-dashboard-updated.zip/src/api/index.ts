import type { User, Project, Task, ClientInput, Meeting, Estimation, ScopeOfWork } from '../types/index.ts';

const API_BASE = '/api';

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API call failed with status ${response.status}: ${errorText}`);
  }
  // Handle 204 No Content for DELETE requests
  if (response.status === 204) {
    return undefined as T;
  }
  return response.json();
}

// --- API FUNCTIONS ---

// Users
export const getUsers = async (): Promise<User[]> => {
  const response = await fetch(`${API_BASE}/users`);
  return handleResponse<User[]>(response);
};

// FIX: Changed the `userData` type to match what the `CreateUserModal` provides. The server handles converting the `projects` string to an array and generating the avatar.
export const createUser = async (userData: Omit<User, 'id' | 'avatar' | 'projects'> & { projects: string }): Promise<User> => {
  const response = await fetch(`${API_BASE}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData),
  });
  return handleResponse<User>(response);
};

// Projects
export const getProjects = async (): Promise<Project[]> => {
  const response = await fetch(`${API_BASE}/projects`);
  return handleResponse<Project[]>(response);
};

export const createProject = async (projectData: Omit<Project, 'id' | 'status' | 'progress'>, userId: string): Promise<Project> => {
  const response = await fetch(`${API_BASE}/projects`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ projectData, userId }),
  });
  return handleResponse<Project>(response);
};

export const updateProject = async (id: string, updatedProjectData: Partial<Project>, userId: string): Promise<Project> => {
  const response = await fetch(`${API_BASE}/projects/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ updatedProjectData, userId }),
  });
  return handleResponse<Project>(response);
};

export const deleteProject = async (id: string): Promise<void> => {
  const response = await fetch(`${API_BASE}/projects/${id}`, {
    method: 'DELETE',
  });
  return handleResponse<void>(response);
};

// Tasks
export const createTask = async (projectId: string, taskData: any, userId: string): Promise<Task> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/tasks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ taskData, userId }),
  });
  return handleResponse<Task>(response);
};

export const updateTask = async (projectId: string, taskId: string, taskData: any, userId: string): Promise<Task> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/tasks/${taskId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ taskData, userId }),
  });
  return handleResponse<Task>(response);
};

export const deleteTask = async (projectId: string, taskId: string, userId: string): Promise<void> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/tasks/${taskId}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId }),
  });
  return handleResponse<void>(response);
};

// Client Inputs
export const createClientInput = async (projectId: string, inputData: any, userId: string): Promise<ClientInput> => {
    const response = await fetch(`${API_BASE}/projects/${projectId}/client-inputs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inputData, userId }),
    });
    return handleResponse<ClientInput>(response);
}

export const updateClientInput = async (projectId: string, inputId: string, inputData: any, userId: string): Promise<ClientInput> => {
    const response = await fetch(`${API_BASE}/projects/${projectId}/client-inputs/${inputId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inputData, userId }),
    });
    return handleResponse<ClientInput>(response);
}

export const deleteClientInput = async (projectId: string, inputId: string, userId: string): Promise<void> => {
    const response = await fetch(`${API_BASE}/projects/${projectId}/client-inputs/${inputId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
    });
    return handleResponse<void>(response);
}

// Meetings
export const createMeeting = async (projectId: string, meetingData: any, userId: string): Promise<Meeting> => {
    const response = await fetch(`${API_BASE}/projects/${projectId}/meetings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ meetingData, userId }),
    });
    return handleResponse<Meeting>(response);
}

// Estimations
export const createEstimation = async (projectId: string, estimationData: any, userId: string): Promise<Estimation> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/estimations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ estimationData, userId }),
  });
  return handleResponse<Estimation>(response);
};

export const updateEstimation = async (projectId: string, estimationId: string, estimationData: any, userId: string): Promise<Estimation> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/estimations/${estimationId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ estimationData, userId }),
  });
  return handleResponse<Estimation>(response);
};

export const deleteEstimation = async (projectId: string, estimationId: string, userId: string): Promise<void> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/estimations/${estimationId}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId }), // Not used by backend but good practice
  });
  return handleResponse<void>(response);
};

// Scope of Work
export const createScopeOfWork = async (projectId: string, scopeData: any, userId: string): Promise<ScopeOfWork> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/scope-of-work`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scopeData, userId }),
  });
  return handleResponse<ScopeOfWork>(response);
};

export const updateScopeOfWork = async (projectId: string, scopeId: string, scopeData: any, userId: string): Promise<ScopeOfWork> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/scope-of-work/${scopeId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scopeData, userId }),
  });
  return handleResponse<ScopeOfWork>(response);
};

export const deleteScopeOfWork = async (projectId: string, scopeId: string, userId: string): Promise<void> => {
  const response = await fetch(`${API_BASE}/projects/${projectId}/scope-of-work/${scopeId}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId }),
  });
  return handleResponse<void>(response);
};